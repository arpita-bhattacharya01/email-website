import { Router, Request, Response } from 'express';
import multer from 'multer';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import {
  signup,
  signin,
  logoutUser,
  getUserProfile,
  updateProfile,
  verifyEmail,
  refreshToken,
  googleAuthCallback,
  forgotPassword,
  adminSignup,
  adminSignin,
  adminLogout,
} from '../controllers/authController.js';
import { sendOTP, verifyOTP } from '../controllers/otpVerification.js';
import { sendEmail, getEmails, getEmailById, updateEmail, trashEmail, deleteEmail } from '../controllers/emailController.js';
import { submitContactForm } from '../controllers/contactController.js';
import { protect, authorizeRoles } from '../middleware/authMiddleware.js';

const router = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Multer file upload config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, join(__dirname, '../Uploads'));
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage, limits: { files: 5 } });

/** 🔓 Public Routes */
router.post('/signup', signup);
router.post('/signin', signin);
router.post('/admin/signup', adminSignup);
router.post('/admin/signin', adminSignin);
router.get('/verify-email/:token', verifyEmail);
router.post('/forgot-password', forgotPassword);
router.post('/send-otp', sendOTP);
router.post('/verify-otp', verifyOTP);
router.post('/contact', submitContactForm);

/** 🔄 Token & OAuth Routes */
router.post('/refresh-token', protect, refreshToken);
router.post('/auth/google', googleAuthCallback);

/** 📧 Email Routes */
router.post('/emails', protect, upload.array('files'), sendEmail);
router.get('/emails', protect, getEmails);
router.get('/emails/:id', protect, getEmailById);
router.put('/emails/:id', protect, updateEmail);
router.post('/emails/:id/trash', protect, trashEmail);
router.delete('/emails/:id', protect, deleteEmail);

/** 🔐 Protected User Routes */
router.post('/logout', protect, logoutUser);
router.post('/admin/logout', protect, authorizeRoles('admin'), adminLogout);
router.get('/user', protect, getUserProfile);
router.put('/user', protect, updateProfile);
router.get('/me', protect, getUserProfile);
router.post('/google/callback', googleAuthCallback);

/** 🔐 Admin Routes */
router.get('/admin/me', protect, authorizeRoles('admin'), (req, res) =>
  res.status(200).json({ success: true, user: req.user })
);
router.get('/admin', protect, authorizeRoles('admin'), (req, res) =>
  res.status(200).json({ success: true, message: 'Welcome, Admin!' })
);

/** 🏓 Health Check Route */
router.get('/ping', (req, res) => res.status(200).send('pong'));

export default router;
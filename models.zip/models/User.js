import promisePool from '../config/db.js';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

/**
 * Create a new user with hashed password and default profile picture.
 * @throws {Error} If role is invalid or query fails.
 */
export const createUser = async ({
  id = uuidv4(),
  firstName,
  lastName,
  email,
  password,
  role = 'user',
  isVerified = false,
  verificationToken = null,
  isBlocked = false,
  isApproved = false,
}) => {
  try {
    // Validate role
    if (!['user', 'admin'].includes(role)) {
      throw new Error('Invalid role: must be "user" or "admin"');
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    // Default profile picture uses Gravatar's mystery person (mp) avatar
    const defaultProfile =
      'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';

    await Promise.race([
      promisePool.query(
        `INSERT INTO users 
          (id, firstName, lastName, email, password_hash, profilePicture, role, isVerified, verificationToken, isBlocked, isApproved, createdAt, updatedAt) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
        [
          id,
          firstName,
          lastName,
          email,
          hashedPassword,
          defaultProfile,
          role,
          isVerified,
          verificationToken,
          isBlocked,
          isApproved,
        ]
      ),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);

    return {
      id,
      firstName,
      lastName,
      email,
      profilePicture: defaultProfile,
      role,
      isVerified,
      isBlocked,
      isApproved,
    };
  } catch (error) {
    console.error('Error creating user:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to create user: ${error.message}`);
  }
};

/**
 * Get user record by email (includes password_hash for login).
 * @throws {Error} If query fails.
 */
export const getUserByEmail = async (email) => {
  try {
    const [rows] = await Promise.race([
      promisePool.query('SELECT * FROM users WHERE email = ?', [email]),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
    return rows[0] || null;
  } catch (error) {
    console.error('Error fetching user by email:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to get user by email: ${error.message}`);
  }
};

/**
 * Get user by ID excluding password_hash.
 * @throws {Error} If query fails.
 */
export const getUserById = async (id) => {
  try {
    const [rows] = await Promise.race([
      promisePool.query(
        `SELECT id, firstName, lastName, email, profilePicture, role, isVerified, lastLogin, isBlocked, isApproved, createdAt, approvedAt 
         FROM users WHERE id = ?`,
        [id]
      ),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
    return rows[0] || null;
  } catch (error) {
    console.error('Error fetching user by ID:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to get user by ID: ${error.message}`);
  }
};

/**
 * Update user's last login timestamp.
 * @throws {Error} If query fails.
 */
export const updateLastLogin = async (userId) => {
  try {
    await Promise.race([
      promisePool.query('UPDATE users SET lastLogin = NOW() WHERE id = ?', [
        userId,
      ]),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
  } catch (error) {
    console.error('Error updating last login:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to update last login: ${error.message}`);
  }
};

/**
 * Compare entered password with hashed password.
 * @throws {Error} If comparison fails.
 */
export const matchPassword = async (enteredPassword, hashedPassword) => {
  try {
    return await bcrypt.compare(enteredPassword, hashedPassword);
  } catch (error) {
    console.error('Error comparing passwords:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to compare passwords: ${error.message}`);
  }
};

/**
 * Get a refresh token record by token string.
 * @throws {Error} If query fails.
 */
export const getRefreshTokenByToken = async (token) => {
  try {
    const [rows] = await Promise.race([
      promisePool.query('SELECT * FROM refresh_tokens WHERE token = ?', [token]),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
    return rows[0] || null;
  } catch (error) {
    console.error('Error fetching refresh token:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to get refresh token: ${error.message}`);
  }
};

/**
 * Save a refresh token for a user.
 * expiresAt is optional; defaults to 30 days from now in DB.
 * @throws {Error} If query fails.
 */
export const saveRefreshToken = async (userId, token, expiresAt = null) => {
  try {
    // Use provided expiresAt or default to 30 days
    const query = expiresAt
      ? 'INSERT INTO refresh_tokens (user_id, token, created_at, expires_at) VALUES (?, ?, NOW(), ?)'
      : 'INSERT INTO refresh_tokens (user_id, token, created_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY))';
    const params = expiresAt ? [userId, token, expiresAt] : [userId, token];

    await Promise.race([
      promisePool.query(query, params),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
  } catch (error) {
    console.error('Error saving refresh token:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to save refresh token: ${error.message}`);
  }
};

/**
 * Delete a specific refresh token by userId and token.
 * @throws {Error} If query fails.
 */
export const deleteRefreshTokenByUserId = async (userId, token) => {
  try {
    await Promise.race([
      promisePool.query(
        'DELETE FROM refresh_tokens WHERE user_id = ? AND token = ?',
        [userId, token]
      ),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
  } catch (error) {
    console.error('Error deleting refresh token:', {
      message: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
    throw new Error(`Failed to delete refresh token: ${error.message}`);
  }
};
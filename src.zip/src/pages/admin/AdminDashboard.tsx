import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Button, Typography } from '@mui/material';
import { Trash2, UserCheck, UserX, UserPlus, Users, Clock } from 'lucide-react';
import { useAdminAuth } from '../../context/AdminAuthContext';
import axios from 'axios';

// Define User type
interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  isBlocked: boolean;
  lastLogin: string | null;
  createdAt: string;
  deletedAt: string | null;
}

// Stats interface
interface Stats {
  totalUsers: number;
  newUsersLast7Days: number;
  deletedUsers: number;
  blockedUsers: number;
  unusedUsersOver30Days: number;
  activeUsersLast7Days: number;
}

const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000',
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
});

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: number }> = ({
  icon,
  label,
  value,
}) => (
  <div className="bg-white p-4 rounded shadow flex items-center gap-3">
    {icon}
    <div>
      <p className="text-sm text-gray-500">{label}</p>
      <p className="text-xl font-bold text-gray-800">{value}</p>
    </div>
  </div>
);

const AdminDashboard: React.FC = () => {
  const { isAdminAuthenticated, logout } = useAdminAuth();
  const navigate = useNavigate();

  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin/signin');
    }
  }, [isAdminAuthenticated, navigate]);

  useEffect(() => {
    if (!isAdminAuthenticated) return;

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [statsRes, usersRes] = await Promise.all([
          apiClient.get('/api/admin/user-stats'),
          apiClient.get('/api/admin/users'),
        ]);

        setStats(statsRes.data);
        setUsers(usersRes.data);
      } catch (e: unknown) {
        const message = e instanceof Error ? e.message : 'Failed to fetch data';
        setError(message);
        console.error('Fetch error:', e);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [isAdminAuthenticated]);

  const handleBlockToggle = async (userId: string, currentlyBlocked: boolean) => {
    setActionLoading(userId);
    try {
      await apiClient.put(`/api/admin/users/${userId}/block`, { block: !currentlyBlocked });
      setUsers((prevUsers) =>
        prevUsers.map((u) => (u.id === userId ? { ...u, isBlocked: !currentlyBlocked } : u))
      );
    } catch (e: unknown) {
      window.alert('Error updating block status');
      console.error('Block toggle error:', e);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;

    setActionLoading(userId);
    try {
      await apiClient.delete(`/api/admin/users/${userId}`);
      setUsers((prevUsers) => prevUsers.filter((u) => u.id !== userId));
    } catch (e: unknown) {
      window.alert('Error deleting user');
      console.error('Delete user error:', e);
    } finally {
      setActionLoading(null);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/signin');
  };

  // Validate chart data
  const chartData = users
    .filter((user) => user.createdAt && !isNaN(new Date(user.createdAt).getTime()))
    .map((user) => ({
      name: `${user.firstName} ${user.lastName}`,
      Age: new Date().getFullYear() - new Date(user.createdAt).getFullYear(),
    }));

  if (loading) return <div className="flex justify-center items-center h-screen">Loading...</div>;
  if (error)
    return (
      <div className="text-center p-6">
        <p className="text-red-600">{error}</p>
        <button onClick={() => window.location.reload()} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">
          Retry
        </button>
      </div>
    );

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <Typography variant="h4" className="text-blue-700">
            Admin Dashboard
          </Typography>
          <p className="text-gray-600">Manage users, stats, and system.</p>
        </div>
        <Button variant="outlined" color="secondary" onClick={handleLogout}>
          Logout
        </Button>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <StatCard icon={<Users size={28} />} label="Total Users" value={stats.totalUsers} />
          <StatCard icon={<UserPlus size={28} />} label="New (7d)" value={stats.newUsersLast7Days} />
          <StatCard icon={<UserX size={28} />} label="Deleted" value={stats.deletedUsers} />
          <StatCard icon={<UserCheck size={28} />} label="Blocked" value={stats.blockedUsers} />
          <StatCard icon={<Clock size={28} />} label=">30d Inactive" value={stats.unusedUsersOver30Days} />
          <StatCard icon={<UserCheck size={28} />} label="Active (7d)" value={stats.activeUsersLast7Days} />
        </div>
      )}

      <div className="bg-white p-6 rounded shadow mb-10">
        <h3 className="text-lg font-bold mb-4 text-gray-800">User Account Overview</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <XAxis dataKey="name" hide />
            <YAxis />
            <Tooltip />
            <Bar dataKey="Age" fill="#3182ce" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white p-6 rounded shadow">
        <h3 className="text-lg font-bold mb-4">Manage Users</h3>
        <ul className="divide-y divide-gray-300">
          {users.map((user) => (
            <li key={user.id} className="py-3 flex justify-between items-center">
              <div>
                <span className="font-medium">{user.firstName} {user.lastName}</span> ({user.email}) -{' '}
                <span className={user.isBlocked ? 'text-red-600' : 'text-green-600'}>
                  {user.isBlocked ? 'Blocked' : 'Active'}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleBlockToggle(user.id, user.isBlocked)}
                  className="px-3 py-1 text-sm bg-yellow-500 text-white rounded hover:bg-yellow-600"
                  disabled={actionLoading === user.id}
                >
                  {user.isBlocked ? 'Unblock' : 'Block'}
                </button>
                <button
                  onClick={() => handleDeleteUser(user.id)}
                  className="px-3 py-1 text-sm bg-red-500 text-white rounded hover:bg-red-600"
                  disabled={actionLoading === user.id}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboard;
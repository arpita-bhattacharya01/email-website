import { Grid } from '@mui/material';

const TestGrid = () => (
  <Grid container>
    <Grid item xs={12}>
      Hello Grid!
    </Grid>
  </Grid>
);

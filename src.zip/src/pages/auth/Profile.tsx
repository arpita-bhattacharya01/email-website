import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

import { User, CheckCircle, XCircle, Settings } from 'lucide-react';
import axios, { AxiosError } from 'axios';

const Profile = () => {
  // Defensive destructuring - fallback to empty object
  const auth = useAuth();
  const user = auth?.user;
  const loading = auth?.isLoading ?? false;
  const logout = auth?.logout ?? (() => {});
  const error = auth?.error ?? null;
  const clearError = auth?.clearError ?? (() => {});
  // Removed fetchProfile as it does not exist on AuthContextType

  const navigate = useNavigate();
  const [editMode, setEditMode] = useState(false);
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [profilePicture, setProfilePicture] = useState<File | null>(null);
  const [profilePicturePreview, setProfilePicturePreview] = useState<string | null>(user?.profilePicture || null);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [updateLoading, setUpdateLoading] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/signin');
      return;
    }
    if (user) {
      setFirstName(user.firstName || '');
      setLastName(user.lastName || '');
      setProfilePicturePreview(user.profilePicture || null);

      const fetchUserProfile = async () => {
        setFetchLoading(true);
        setLocalError(null);
        clearError();
        try {
          const res = await axios.get('/api/user');
          if (res.data.success && res.data.user) {
            // Removed fetchProfile call as it does not exist
            setFirstName(res.data.user.firstName || '');
            setLastName(res.data.user.lastName || '');
            setProfilePicturePreview(res.data.user.profilePicture || null);
            localStorage.setItem('user', JSON.stringify(res.data.user));
          } else {
            throw new Error('No user data returned');
          }
        } catch (err) {
          let errorMessage = 'Failed to fetch profile data. Please try again.';
          if (axios.isAxiosError(err) && err.response?.data?.message) {
            errorMessage = err.response.data.message;
          }
          setLocalError(errorMessage);
        } finally {
          setFetchLoading(false);
        }
      };
      fetchUserProfile();
    }
  }, [user, loading, navigate, clearError]);

  const handleProfilePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/jpg', 'image/png'].includes(file.type)) {
        setLocalError('Please upload a JPEG or PNG image');
        return;
      }
      setProfilePicture(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicturePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateProfile = async () => {
    if (!firstName || !lastName) {
      setLocalError('First name and last name are required');
      return;
    }
    setUpdateLoading(true);
    setLocalError(null);
    setSuccessMessage(null);
    clearError();

    try {
      let profilePictureUrl = user?.profilePicture || '';
      if (profilePicture) {
        const formData = new FormData();
        formData.append('profilePicture', profilePicture);
        const uploadRes = await axios.post('/api/upload-profile-picture', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        if (uploadRes.data.success) {
          profilePictureUrl = uploadRes.data.url;
        } else {
          throw new Error(uploadRes.data.message || 'Failed to upload profile picture');
        }
      }

      const res = await axios.put('/api/user/update', {
        firstName,
        lastName,
        profilePicture: profilePictureUrl,
      });

      if (res.data.success) {
        // Removed fetchProfile call as it does not exist
        setEditMode(false);
        setProfilePicture(null);
        setSuccessMessage('Profile updated successfully');
      } else {
        throw new Error(res.data.message || 'Failed to update profile');
      }
    } catch (err) {
      let errorMessage = 'Failed to update profile. Please try again.';
      if (axios.isAxiosError(err) && err.response?.data?.message) {
        errorMessage = err.response.data.message;
      }
      setLocalError(errorMessage);
    } finally {
      setUpdateLoading(false);
    }
  };

  const handleCancel = () => {
    setEditMode(false);
    setFirstName(user?.firstName || '');
    setLastName(user?.lastName || '');
    setProfilePicture(null);
    setProfilePicturePreview(user?.profilePicture || null);
    setLocalError(null);
    setSuccessMessage(null);
    clearError();
  };

  const handleAdminDashboard = () => {
    navigate('/admin-dashboard');
  };

  if (loading || fetchLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-gray-600 animate-pulse">Loading...</p>
      </div>
    );
  }

  if (!user) {
    return null; // Redirect handled by useEffect
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center">
            <User className="h-16 w-16 text-blue-600" />
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Your Profile</h2>
          <p className="mt-2 text-sm text-gray-600">
            Role: <span className="font-medium capitalize">{user.role || 'N/A'}</span>
          </p>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6 space-y-6">
          {(error || localError) && (
            <p className="text-red-600 text-center">{error || localError}</p>
          )}
          {successMessage && (
            <p className="text-green-600 text-center">{successMessage}</p>
          )}
          <div className="space-y-4">
            {editMode ? (
              <>
                <div className="flex flex-col space-y-2">
                  <label htmlFor="firstName" className="text-gray-600 font-medium">
                    First Name
                  </label>
                  <input
                    id="firstName"
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="border rounded-md p-2 w-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
                    disabled={updateLoading}
                    aria-required="true"
                  />
                </div>
                <div className="flex flex-col space-y-2">
                  <label htmlFor="lastName" className="text-gray-600 font-medium">
                    Last Name
                  </label>
                  <input
                    id="lastName"
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="border rounded-md p-2 w-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
                    disabled={updateLoading}
                    aria-required="true"
                  />
                </div>
                <div className="flex flex-col space-y-2">
                  <label htmlFor="profilePicture" className="text-gray-600 font-medium">
                    Profile Picture
                  </label>
                  <div className="flex items-center space-x-4">
                    {profilePicturePreview && (
                      <img
                        src={profilePicturePreview}
                        alt="Profile Preview"
                        className="h-16 w-16 rounded-full object-cover"
                        onError={(e) => (e.currentTarget.src = '/placeholder.png')}
                      />
                    )}
                    <input
                      id="profilePicture"
                      type="file"
                      accept="image/jpeg,image/jpg,image/png"
                      onChange={handleProfilePictureChange}
                      className="border rounded-md p-2 w-full text-gray-900 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                      disabled={updateLoading}
                    />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center space-x-3">
                  <span className="text-gray-600 font-medium">First Name:</span>
                  <span className="text-gray-900">{user.firstName || 'N/A'}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-gray-600 font-medium">Last Name:</span>
                  <span className="text-gray-900">{user.lastName || 'N/A'}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-gray-600 font-medium">Email:</span>
                  <span className="text-gray-900">{user.email}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-gray-600 font-medium">Verified:</span>
                  <span className="flex items-center space-x-1">
                    {user.isVerified ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={user.isVerified ? 'text-green-600' : 'text-red-600'}>
                      {user.isVerified ? 'Yes' : 'No'}
                    </span>
                  </span>
                </div>
                {user.profilePicture && (
                  <div className="flex items-center space-x-3">
                    <span className="text-gray-600 font-medium">Profile Picture:</span>
                    <img
                      src={user.profilePicture}
                      alt="Profile"
                      className="h-16 w-16 rounded-full object-cover"
                      onError={(e) => (e.currentTarget.src = '/placeholder.png')}
                    />
                  </div>
                )}
              </>
            )}
          </div>
          <div className="space-y-2">
            {editMode ? (
              <>
                <button
                  onClick={handleUpdateProfile}
                  disabled={updateLoading}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:cursor-not-allowed"
                >
                  {updateLoading ? (
                    <span className="flex items-center">
                      <svg
                        className="animate-spin h-5 w-5 mr-2 text-white"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                          fill="none"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8v8H4z"
                        />
                      </svg>
                      Saving...
                    </span>
                  ) : (
                    'Save Profile'
                  )}
                </button>
                <button
                  onClick={handleCancel}
                  disabled={updateLoading}
                  className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:bg-gray-200 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setEditMode(true)}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Edit Profile
                </button>
                {user.role === 'admin' && (
                  <button
                    onClick={handleAdminDashboard}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                  >
                    <Settings className="h-5 w-5 mr-2" />
                    Admin Dashboard
                  </button>
                )}
              </>
            )}
            <button
              onClick={() => logout()}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              Log Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

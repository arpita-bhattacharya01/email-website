import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  InputAdornment,
  IconButton,
  Checkbox,
  FormControlLabel,
  useTheme,
  Alert,
} from '@mui/material';
import { Grid } from '@mui/material';
import { Visibility, VisibilityOff, Email } from '@mui/icons-material';
import { motion } from 'framer-motion';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useNavigate, Link } from 'react-router-dom';
import { useAdminAuth } from '../../context/AdminAuthContext';

// Validation Schema
const schema = yup.object().shape({
  email: yup
    .string()
    .email('Invalid email')
    .required('Email is required')
    .matches(/\d{4}/, 'Email must contain at least 4 digits'),
  password: yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
});

type SignInFormData = {
  email: string;
  password: string;
};

const AdminSignIn: React.FC = () => {
  const { signin } = useAdminAuth();
  const navigate = useNavigate();
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const {
    handleSubmit,
    control,
    setValue,
    formState: { errors },
  } = useForm<SignInFormData>({
    resolver: yupResolver(schema),
    defaultValues: { email: '', password: '' },
  });

  useEffect(() => {
    const remembered = localStorage.getItem('rememberedAdminEmail');
    if (remembered) {
      setValue('email', remembered);
      setRememberMe(true);
    }
  }, [setValue]);

  const onSubmit = async (data: SignInFormData) => {
    setError('');
    try {
      await signin(data.email, data.password);
      if (rememberMe) {
        localStorage.setItem('rememberedAdminEmail', data.email);
      } else {
        localStorage.removeItem('rememberedAdminEmail');
      }
      navigate('/admin/dashboard', { replace: true });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Login failed';
      setError(message);
      console.error('Sign-in error:', err);
    }
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      sx={{ minHeight: '100vh', bgcolor: theme.palette.background.default, p: theme.spacing(2) }}
    >
      <Grid item xs={11} sm={8} md={6} lg={4}>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card sx={{ boxShadow: 3, borderRadius: 3, bgcolor: isDark ? '#333' : '#fff' }}>
            <CardContent sx={{ px: theme.spacing(4), py: theme.spacing(5) }}>
              <Typography
                variant="h5"
                fontWeight={500}
                textAlign="center"
                mb={theme.spacing(3)}
                color={isDark ? '#fff' : '#000'}
              >
                Admin Sign In
              </Typography>

              {error && (
                <Alert severity="error" sx={{ mb: theme.spacing(3) }} data-testid="error-alert">
                  {error}
                </Alert>
              )}

              <form onSubmit={handleSubmit(onSubmit)} noValidate aria-label="Admin Sign-in form">
                <Controller
                  name="email"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Admin Email"
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.email}
                      helperText={errors.email?.message || 'Email must contain at least 4 digits (e.g., admin1234@domain.com)'}
                      placeholder="admin1234@domain.com"
                      margin="normal"
                      autoComplete="username"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <Email />
                          </InputAdornment>
                        ),
                      }}
                      data-testid="admin-email-input"
                    />
                  )}
                />

                <Controller
                  name="password"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.password}
                      helperText={errors.password?.message}
                      placeholder="Minimum 8 characters"
                      margin="normal"
                      autoComplete="current-password"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={() => setShowPassword(!showPassword)}
                              edge="end"
                              aria-label={showPassword ? 'Hide password' : 'Show password'}
                            >
                              {showPassword ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                      data-testid="admin-password-input"
                    />
                  )}
                />

                <Grid container justifyContent="space-between" alignItems="center" sx={{ my: theme.spacing(2) }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        value="remember"
                        color="primary"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        data-testid="remember-me-checkbox"
                      />
                    }
                    label="Remember Me"
                  />

                  <Link
                    to="/forgot-password"
                    style={{ textDecoration: 'none', fontSize: '0.875rem', color: theme.palette.primary.main }}
                    aria-label="Forgot password"
                  >
                    Forgot Password?
                  </Link>
                </Grid>

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{
                    bgcolor: theme.palette.primary.main,
                    fontWeight: 500,
                    textTransform: 'none',
                    py: theme.spacing(1.5),
                    borderRadius: 1,
                    '&:hover': { bgcolor: theme.palette.primary.dark },
                    mb: theme.spacing(2),
                  }}
                  aria-label="Sign in"
                  data-testid="submit-button"
                >
                  Sign In
                </Button>
              </form>

              <Typography
                variant="body2"
                textAlign="center"
                color={isDark ? theme.palette.text.secondary : theme.palette.text.primary}
              >
                Don’t have an account?{' '}
                <Link
                  to="/admin/signup"
                  style={{ color: theme.palette.primary.main, textDecoration: 'none', fontWeight: 'bold' }}
                  aria-label="Admin sign up"
                >
                  Sign Up
                </Link>
              </Typography>

              <Typography
                variant="body2"
                textAlign="center"
                mt={2}
                color={isDark ? theme.palette.text.secondary : theme.palette.text.primary}
              >
                User?{' '}
                <Link
                  to="/"
                  style={{ color: theme.palette.primary.main, textDecoration: 'none', fontWeight: 'bold' }}
                  aria-label="User sign in"
                >
                  Sign in as User
                </Link>
              </Typography>
            </CardContent>
          </Card>
        </motion.div>
      </Grid>
    </Grid>
  );
};

export default AdminSignIn;
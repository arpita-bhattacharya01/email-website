import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  InputAdornment,
  IconButton,
  Checkbox,
  FormControlLabel,
  useTheme,
  Alert,
  AlertTitle,
  FormHelperText,
} from '@mui/material';
import { Grid } from '@mui/material';
import { Visibility, VisibilityOff, Email } from '@mui/icons-material';
import { motion } from 'framer-motion';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

// Validation Schema
const schema = yup.object().shape({
  email: yup
    .string()
    .email('Invalid email')
    .required('Email is required')
    .matches(/\d{4}/, 'Email must contain at least 4 digits'),
  password: yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
});

type SignInFormData = {
  email: string;
  password: string;
};

const SignIn: React.FC = () => {
  const { isAuthenticated, role, signIn, isLoading, error: authError, clearError } = useAuth();
  const navigate = useNavigate();
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';

  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState<boolean>(false);

  const {
    handleSubmit,
    control,
    setValue,
    formState: { errors },
  } = useForm<SignInFormData>({
    resolver: yupResolver(schema),
    defaultValues: { email: '', password: '' },
  });

  useEffect(() => {
    // Redirect based on authentication and role
    if (isAuthenticated && role) {
      navigate(role === 'admin' ? '/admin-dashboard' : '/user-dashboard', { replace: true });
    }

    // Load remembered email if available
    const remembered = localStorage.getItem('rememberedEmail');
    if (remembered) {
      setValue('email', remembered);
      setRememberMe(true);
    }
  }, [isAuthenticated, role, navigate, setValue]);

  const onSubmit = async (data: SignInFormData) => {
    clearError();
    try {
      const result = await signIn(data.email, data.password);
      if (result.success) {
        if (rememberMe) {
          localStorage.setItem('rememberedEmail', data.email);
        } else {
          localStorage.removeItem('rememberedEmail');
        }
        // Navigate to appropriate dashboard based on role
        navigate(result.role === 'admin' ? '/admin-dashboard' : '/user-dashboard', { replace: true });
      } else {
        throw new Error(result.message || 'Sign-in failed.');
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Server error, please try again later.';
      clearError();
      throw new Error(errorMsg);
    }
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      sx={{ minHeight: '100vh', bgcolor: theme.palette.background.default, p: theme.spacing(2) }}
    >
      <Grid component="div" item xs={11} sm={8} md={6} lg={4}>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card sx={{ boxShadow: 3, borderRadius: 3, bgcolor: isDark ? '#333' : '#fff' }}>
            <CardContent sx={{ px: theme.spacing(4), py: theme.spacing(5) }}>
              <Typography
                variant="h5"
                fontWeight={500}
                textAlign="center"
                mb={theme.spacing(3)}
                color={isDark ? '#fff' : '#000'}
              >
                User Sign In
              </Typography>

              {authError && (
                <Alert severity="error" sx={{ mb: theme.spacing(3) }} data-testid="error-alert">
                  <AlertTitle>Error</AlertTitle>
                  {authError}
                </Alert>
              )}

              <form onSubmit={handleSubmit(onSubmit)} noValidate aria-label="Sign-in form">
                <Controller
                  name="email"
                  control={control}
                  render={({ field }) => (
                    <>
                      <TextField
                        {...field}
                        label="Email"
                        fullWidth
                        size="small"
                        variant="outlined"
                        error={!!errors.email}
                        helperText={errors.email?.message}
                        placeholder="username1234@domain.com"
                        margin="normal"
                        autoComplete="username"
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Email />
                            </InputAdornment>
                          ),
                        }}
                        disabled={isLoading}
                        data-testid="email-input"
                      />
                      <FormHelperText sx={{ mt: -1, mb: 1 }}>
                        Email must contain at least 4 digits (e.g., username1234@domain.com)
                      </FormHelperText>
                    </>
                  )}
                />

                <Controller
                  name="password"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.password}
                      helperText={errors.password?.message}
                      placeholder="Minimum 8 characters"
                      margin="normal"
                      autoComplete="current-password"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={() => setShowPassword(!showPassword)}
                              edge="end"
                              aria-label={showPassword ? 'Hide password' : 'Show password'}
                            >
                              {showPassword ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                      disabled={isLoading}
                      data-testid="password-input"
                    />
                  )}
                />

                <Grid container justifyContent="space-between" alignItems="center" sx={{ my: theme.spacing(2) }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        value="remember"
                        color="primary"
                        checked={rememberMe}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRememberMe(e.target.checked)}
                        data-testid="remember-me-checkbox"
                      />
                    }
                    label="Remember Me"
                  />

                  <Link
                    to="/forgot-password"
                    style={{ textDecoration: 'none', fontSize: '0.875rem', color: theme.palette.primary.main }}
                    aria-label="Forgot password"
                  >
                    Forgot Password?
                  </Link>
                </Grid>

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{
                    bgcolor: theme.palette.primary.main,
                    fontWeight: 500,
                    textTransform: 'none',
                    py: theme.spacing(1.5),
                    borderRadius: 1,
                    '&:hover': { bgcolor: theme.palette.primary.dark },
                    mb: 2,
                  }}
                  disabled={isLoading}
                  aria-label="Sign in"
                  data-testid="submit-button"
                >
                  {isLoading ? 'Loading...' : 'Sign In'}
                </Button>
              </form>

              <Typography
                variant="body2"
                textAlign="center"
                color={isDark ? theme.palette.text.secondary : theme.palette.text.primary}
              >
                New user?{' '}
                <Link
                  to="/signup"
                  style={{ color: theme.palette.primary.main, textDecoration: 'none', fontWeight: 'bold' }}
                  aria-label="Create an account"
                >
                  Create an account
                </Link>
              </Typography>

              <Typography
                variant="body2"
                textAlign="center"
                mt={2}
                color={isDark ? theme.palette.text.secondary : theme.palette.text.primary}
              >
                Admin?{' '}
                <Link
                  to="/admin"
                  style={{ color: theme.palette.primary.main, textDecoration: 'none', fontWeight: 'bold' }}
                  aria-label="Admin sign in"
                >
                  Sign in as Admin
                </Link>
              </Typography>
            </CardContent>
          </Card>
        </motion.div>
      </Grid>
    </Grid>
  );
};

export default SignIn;
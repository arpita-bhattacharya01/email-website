import React, { useState } from 'react';
import {
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  InputAdornment,
  IconButton,
  useTheme,
  Alert,
  AlertTitle,
  Grid,
  FormHelperText,
} from '@mui/material';
import { Visibility, VisibilityOff, Email, Person } from '@mui/icons-material';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useAuth } from '../../context/AuthContext';

// Validation Schema
const schema = yup.object().shape({
  firstName: yup.string().required('First Name is required').min(2, 'First Name must be at least 2 characters'),
  lastName: yup.string().required('Last Name is required').min(2, 'Last Name must be at least 2 characters'),
  email: yup
    .string()
    .email('Invalid email')
    .required('Email is required')
    .matches(/\d{4}/, 'Email must contain at least 4 digits'),
  password: yup
    .string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required')
    .matches(/^(?=.*[a-zA-Z])(?=.*\d)/, 'Password must include at least one letter and one number'),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref('password')], 'Passwords must match')
    .required('Confirm Password is required'),
});

type SignUpFormData = {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
};

const SignUp: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { signup, isLoading, error: authError, clearError } = useAuth();
  const navigate = useNavigate();
  const theme = useTheme();
  const isDark = theme?.palette?.mode === 'dark';

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<SignUpFormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  const onSubmit = async (data: SignUpFormData) => {
    clearError();
    try {
      console.log('Submitting signup form:', data);
      await signup(data.firstName, data.lastName, data.email, data.password, data.confirmPassword);
      console.log('Signup successful, navigating to /signin');
      navigate('/signin');
    } catch (err) {
      console.error('Sign-up error:', err);
      // Error is handled by AuthContext
    }
  };

  console.log('Rendering SignUp component');

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      sx={{ minHeight: '100vh', bgcolor: isDark ? '#333' : '#f0f2f5', p: 2 }}
    >
      <Grid
        sx={{
          width: { xs: '91.67%', sm: '66.67%', md: '50%', lg: '33.33%' },
        }}
      >
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card sx={{ boxShadow: 3, borderRadius: 3, bgcolor: isDark ? '#333' : '#fff' }}>
            <CardContent sx={{ px: 4, py: 5 }}>
              <Typography variant="h5" fontWeight={500} textAlign="center" mb={3} color={isDark ? '#fff' : '#000'}>
                Sign Up
              </Typography>

              {authError && (
                <Alert severity="error" sx={{ mb: 3 }} data-testid="error-alert">
                  <AlertTitle>Error</AlertTitle>
                  {authError}
                </Alert>
              )}

              <form onSubmit={handleSubmit(onSubmit)} noValidate aria-label="Sign-up form">
                <Controller
                  name="firstName"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="First Name"
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.firstName}
                      helperText={errors.firstName?.message}
                      placeholder="John"
                      margin="normal"
                      required
                      disabled={isLoading}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <Person />
                          </InputAdornment>
                        ),
                      }}
                      data-testid="firstName-input"
                    />
                  )}
                />

                <Controller
                  name="lastName"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Last Name"
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.lastName}
                      helperText={errors.lastName?.message}
                      placeholder="Doe"
                      margin="normal"
                      required
                      disabled={isLoading}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <Person />
                          </InputAdornment>
                        ),
                      }}
                      data-testid="lastName-input"
                    />
                  )}
                />

                <Controller
                  name="email"
                  control={control}
                  render={({ field }) => (
                    <>
                      <TextField
                        {...field}
                        label="Email"
                        type="email"
                        fullWidth
                        size="small"
                        variant="outlined"
                        error={!!errors.email}
                        helperText={errors.email?.message}
                        placeholder="username1234@domain.com"
                        margin="normal"
                        required
                        disabled={isLoading}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <Email />
                            </InputAdornment>
                          ),
                        }}
                        data-testid="email-input"
                      />
                      <FormHelperText sx={{ mt: -1, mb: 1 }}>
                        Email must contain at least 4 digits (e.g., username1234@domain.com)
                      </FormHelperText>
                    </>
                  )}
                />

                <Controller
                  name="password"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Password"
                      type={showPassword ? 'text' : 'password'}
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.password}
                      helperText={errors.password?.message}
                      placeholder="Minimum 8 characters"
                      margin="normal"
                      required
                      disabled={isLoading}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={() => setShowPassword(!showPassword)}
                              edge="end"
                              aria-label={showPassword ? 'Hide password' : 'Show password'}
                              tabIndex={-1}
                            >
                              {showPassword ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                      data-testid="password-input"
                    />
                  )}
                />

                <Controller
                  name="confirmPassword"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Confirm Password"
                      type={showConfirmPassword ? 'text' : 'password'}
                      fullWidth
                      size="small"
                      variant="outlined"
                      error={!!errors.confirmPassword}
                      helperText={errors.confirmPassword?.message}
                      placeholder="Confirm your password"
                      margin="normal"
                      required
                      disabled={isLoading}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                              edge="end"
                              aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                              tabIndex={-1}
                            >
                              {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                      data-testid="confirmPassword-input"
                    />
                  )}
                />

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{
                    bgcolor: '#1a73e8',
                    fontWeight: 500,
                    textTransform: 'none',
                    py: 1.5,
                    borderRadius: 1,
                    '&:hover': { bgcolor: '#1557b0' },
                    mb: 2,
                  }}
                  disabled={isLoading}
                  aria-label="Sign up"
                  data-testid="submit-button"
                >
                  {isLoading ? 'Signing Up...' : 'Sign Up'}
                </Button>
              </form>

              <Typography variant="body2" textAlign="center" color={isDark ? '#ccc' : '#555'}>
                Already have an account?{' '}
                <Link
                  to="/signin"
                  style={{ color: '#1a73e8', textDecoration: 'none', fontWeight: 'bold' }}
                  aria-label="Sign in"
                >
                  Sign In
                </Link>
              </Typography>
            </CardContent>
          </Card>
        </motion.div>
      </Grid>
    </Grid>
  );
};

export default SignUp;
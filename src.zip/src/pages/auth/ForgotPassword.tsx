// src/pages/auth/ForgotPassword.tsx
import React, { useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  Alert,
  Grid,
  useTheme
} from '@mui/material';
import { motion } from 'framer-motion';
import { useAuth } from '../../context/AuthContext';

const ForgotPassword: React.FC = () => {
  const { forgotPassword, error } = useAuth();
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');
    try {
      await forgotPassword(email);
      setMessage('Password reset link sent successfully.');
    } catch (err) {
      setMessage('Failed to send reset link.');
    }
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      sx={{
        minHeight: '100vh',
        bgcolor: isDark ? '#333' : '#f0f2f5',
        p: 2,
      }}
    >
      <Grid
        sx={{
          width: { xs: '91.67%', sm: '66.67%', md: '50%', lg: '33.33%' },
        }}
      >
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card sx={{ boxShadow: 3, borderRadius: 3, bgcolor: isDark ? '#333' : '#fff' }}>
            <CardContent sx={{ px: 4, py: 5 }}>
              <Typography
                variant="h5"
                fontWeight={500}
                textAlign="center"
                mb={3}
                color={isDark ? '#fff' : '#000'}
              >
                Forgot Password
              </Typography>

              {message && (
                <Alert severity="success" sx={{ mb: 2 }}>
                  {message}
                </Alert>
              )}
              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              <form onSubmit={handleSubmit} noValidate>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  required
                  variant="outlined"
                  size="small"
                  placeholder="Enter your registered email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  sx={{ mb: 3 }}
                />

                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{
                    bgcolor: '#1a73e8',
                    fontWeight: 500,
                    textTransform: 'none',
                    py: 1.5,
                    borderRadius: 1,
                    '&:hover': { bgcolor: '#1557b0' },
                  }}
                >
                  Send Reset Link
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </Grid>
    </Grid>
  );
};

export default ForgotPassword;

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate, useSearchParams } from 'react-router-dom';

const VerifyEmail: React.FC = () => {
  const [error, setError] = useState<string | null>(null);
  const { verifyEmail } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const verify = async () => {
      const token = searchParams.get('token');
      if (token) {
        try {
          await verifyEmail(token);
          navigate('/user-dashboard');
        } catch (err) {
          setError((err as Error).message || 'Email verification failed');
        }
      } else {
        setError('No verification token provided');
      }
    };
    verify();
  }, [searchParams, verifyEmail, navigate]);

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-center">Verify Email</h2>
      {error ? (
        <p className="text-red-500 mb-4">{error}</p>
      ) : (
        <p>Verifying your email...</p>
      )}
    </div>
  );
};

export default VerifyEmail;
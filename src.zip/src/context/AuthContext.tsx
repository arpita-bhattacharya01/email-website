import React, { createContext, useState, useEffect, ReactNode, useContext } from 'react';
import axios, { AxiosError } from 'axios';

type Role = 'user' | 'admin' | null;

interface User {
  id?: string;
  email: string;
  firstName?: string;
  lastName?: string;
  isVerified?: boolean;
  profilePicture?: string;
}

type Step = 'EMAIL' | 'AUTHENTICATED';

interface AuthContextType {
  user: User | null;
  step: Step;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  role: Role;
  signup: (
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    confirmPassword: string
  ) => Promise<void>;
  adminSignup: (
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ) => Promise<void>;
  verifyEmail: (token: string) => Promise<void>;
  signIn: (
    email: string,
    password: string
  ) => Promise<{ success: boolean; message?: string; role?: Role }>;
  forgotPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
  setUser: (user: User) => void;
}

const defaultAuthContext: AuthContextType = {
  user: null,
  step: 'EMAIL',
  isLoading: false,
  error: null,
  isAuthenticated: false,
  role: null,
  signup: async () => {},
  adminSignup: async () => {},
  verifyEmail: async () => {},
  signIn: async () => ({ success: false }),
  forgotPassword: async () => {},
  logout: async () => {},
  clearError: () => {},
  setUser: () => {},
};

const AuthContext = createContext<AuthContextType>(defaultAuthContext);

// Dedicated axios instance
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
});

apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [step, setStep] = useState<Step>('EMAIL');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [role, setRole] = useState<Role>(null);

  useEffect(() => {
    const fetchUser = async () => {
      const token = localStorage.getItem('authToken');
      setIsLoading(true);
      try {
        if (token) {
          const res = await apiClient.get('/api/user');
          setUser(res.data.user);
          setRole(res.data.user.role || 'user');
          setIsAuthenticated(true);
          setStep('AUTHENTICATED');
        }
      } catch (err: unknown) {
        console.error('Fetch user error:', err);
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        localStorage.removeItem('userRole');
        setUser(null);
        setRole(null);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  const clearError = () => setError(null);

  const validateEmail = (email: string) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
    const digitCount = (email.match(/\d/g) || []).length;
    return emailRegex.test(email) && digitCount >= 4;
  };

  const validatePassword = (password: string) =>
    password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password);

  const signup = async (
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    confirmPassword: string
  ) => {
    setIsLoading(true);
    clearError();
    try {
      if (!firstName || !lastName || !email || !password || !confirmPassword) {
        throw new Error('All fields are required');
      }
      if (!validateEmail(email)) {
        throw new Error('Email must be valid and include at least 4 digits');
      }
      if (!validatePassword(password)) {
        throw new Error('Password must be at least 8 characters and include letters and numbers');
      }
      if (password !== confirmPassword) {
        throw new Error('Passwords do not match');
      }

      const res = await apiClient.post('/api/signup', {
        firstName,
        lastName,
        email,
        password,
        confirmPassword,
      });

      if (!res.data.success) {
        throw new Error(res.data.message || 'Signup failed');
      }

      setUser(res.data.user);
      setRole('user');
      localStorage.setItem('authToken', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      localStorage.setItem('userRole', 'user');
    } catch (err: unknown) {
      const message =
        err instanceof AxiosError && err.response?.data?.message
          ? err.response.data.message
          : err instanceof Error
          ? err.message
          : 'Signup failed';
      setError(message);
      throw new Error(message);
    } finally {
      setIsLoading(false);
    }
  };

  const adminSignup = async (
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ) => {
    setIsLoading(true);
    clearError();
    try {
      if (!firstName || !lastName || !email || !password) {
        throw new Error('All fields are required');
      }
      if (!validateEmail(email)) {
        throw new Error('Email must be valid and include at least 4 digits');
      }
      if (!validatePassword(password)) {
        throw new Error('Password must be at least 8 characters and include letters and numbers');
      }

      const res = await apiClient.post('/api/admin/signup', {
        firstName,
        lastName,
        email,
        password,
      });

      if (!res.data.success) {
        throw new Error(res.data.message || 'Admin signup failed');
      }
    } catch (err: unknown) {
      const message =
        err instanceof AxiosError && err.response?.data?.message
          ? err.response.data.message
          : err instanceof Error
          ? err.message
          : 'Admin signup failed';
      setError(message);
      throw new Error(message);
    } finally {
      setIsLoading(false);
    }
  };

  const verifyEmail = async (token: string) => {
    setIsLoading(true);
    clearError();
    try {
      if (!token) {
        throw new Error('Missing token');
      }

      const res = await apiClient.get(`/api/verify-email/${token}`);
      if (!res.data.success) {
        throw new Error(res.data.message || 'Verification failed');
      }

      setUser(res.data.user);
      setIsAuthenticated(true);
      setRole('user');
      setStep('AUTHENTICATED');
      localStorage.setItem('authToken', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      localStorage.setItem('userRole', 'user');
    } catch (err: unknown) {
      const message =
        err instanceof AxiosError && err.response?.data?.message
          ? err.response.data.message
          : err instanceof Error
          ? err.message
          : 'Verification failed';
      setError(message);
      throw new Error(message);
    } finally {
      setIsLoading(false);
    }
  };

  const signIn = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; message?: string; role?: Role }> => {
    setIsLoading(true);
    clearError();
    try {
      const res = await apiClient.post('/api/signin', { email, password });
      if (!res.data.success) {
        throw new Error(res.data.message || 'Signin failed');
      }

      setUser(res.data.user);
      setIsAuthenticated(true);
      setRole(res.data.user.role || 'user');
      setStep('AUTHENTICATED');
      localStorage.setItem('authToken', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      localStorage.setItem('userRole', res.data.user.role || 'user');

      return { success: true, role: res.data.user.role || 'user' };
    } catch (err: unknown) {
      const message =
        err instanceof AxiosError && err.response?.data?.message
          ? err.response.data.message
          : err instanceof Error
          ? err.message
          : 'Signin failed';
      setError(message);
      return { success: false, message, role: undefined };
    } finally {
      setIsLoading(false);
    }
  };

  const forgotPassword = async (email: string) => {
    setIsLoading(true);
    clearError();
    try {
      if (!validateEmail(email)) {
        throw new Error('Invalid email format');
      }

      const res = await apiClient.post('/api/forgot-password', { email });
      if (!res.data.success) {
        throw new Error(res.data.message || 'Reset failed');
      }
    } catch (err: unknown) {
      const message =
        err instanceof AxiosError && err.response?.data?.message
          ? err.response.data.message
          : err instanceof Error
          ? err.message
          : 'Reset failed';
      setError(message);
      throw new Error(message);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    clearError();
    try {
      await apiClient.post('/api/logout');
    } catch (err: unknown) {
      console.error('Logout error:', err);
    } finally {
      localStorage.removeItem('authToken');
      localStorage.removeItem('user');
      localStorage.removeItem('userRole');
      localStorage.removeItem('isAdminAuthenticated');
      setUser(null);
      setRole(null);
      setIsAuthenticated(false);
      setStep('EMAIL');
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        step,
        isLoading,
        error,
        isAuthenticated,
        role,
        signup,
        adminSignup,
        verifyEmail,
        signIn,
        forgotPassword,
        logout,
        clearError,
        setUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
export { AuthContext, AuthProvider };
export default AuthProvider;
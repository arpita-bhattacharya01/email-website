import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

// Create a new axios instance with a hardcoded baseURL
const apiClient = axios.create({
  baseURL: 'https://your-api-url.com', // Replace with your actual API URL
  headers: { 'Content-Type': 'application/json' },
});

interface AdminAuthContextType {
  isAdminAuthenticated: boolean;
  signin: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

export const AdminAuthContext = React.createContext<AdminAuthContextType | null>(null);

export const useAdminAuth = (): AdminAuthContextType => {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};

export const AdminAuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    const checkAdminSession = async () => {
      try {
        const res = await apiClient.get('/api/admin/me', { withCredentials: true });
        if (res.status === 200) {
          setIsAdminAuthenticated(true);
        }
      } catch {
        setIsAdminAuthenticated(false);
      }
    };

    checkAdminSession();
  }, []);

  const signin = async (email: string, password: string) => {
    try {
      const res = await apiClient.post('/api/admin/signin', {
        email,
        password,
      }, { withCredentials: true });
      if (res.status === 200) {
        setIsAdminAuthenticated(true);
      }
    } catch (err: any) {
      console.error('Admin login failed:', err);
      setIsAdminAuthenticated(false);
      throw err;
    }
  };

  const logout = async () => {
    try {
      await apiClient.post('/api/admin/logout', {}, { withCredentials: true });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setIsAdminAuthenticated(false);
    }
  };

  return (
    <AdminAuthContext.Provider value={{ isAdminAuthenticated, signin, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};
import React, { useEffect, Suspense, Component, ReactNode } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Outlet,
  useLocation,
} from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AdminAuthProvider } from './context/AdminAuthContext';
import AdminProtectedRoute from './context/AdminProtectedRoute';
import './index.css';

// Lazy-loaded components
const SignIn = React.lazy(() => import('./pages/auth/SignIn'));
const SignUp = React.lazy(() => import('./pages/auth/SignUp'));
const VerifyEmail = React.lazy(() => import('./pages/auth/VerifyEmail'));
const Inbox = React.lazy(() => import('./pages/Inbox'));
const EmailView = React.lazy(() => import('./pages/EmailView'));
const ComposeEmail = React.lazy(() => import('./pages/ComposeEmail'));
const Logout = React.lazy(() => import('./pages/auth/Logout'));
const Profile = React.lazy(() => import('./pages/auth/Profile'));
const ForgotPassword = React.lazy(() => import('./pages/auth/ForgotPassword'));
const ResetPassword = React.lazy(() => import('./pages/auth/ResetPassword'));
const UserDashboard = React.lazy(() => import('./pages/user/UserDashboard'));
const AdminDashboard = React.lazy(() => import('./pages/admin/AdminDashboard'));
const AdminSignIn = React.lazy(() => import('./pages/admin/AdminSignIn'));
const AdminSignUp = React.lazy(() => import('./pages/admin/AdminSignUp'));

// Error Boundary Component
type ErrorBoundaryState = { hasError: boolean; error: Error | null };

class ErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    console.error('ErrorBoundary caught:', error);
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="text-center mt-20">
          <h2 className="text-2xl font-bold text-red-600">Something went wrong.</h2>
          <p className="text-gray-600">{this.state.error?.message || 'Please try refreshing the page or contact support.'}</p>
        </div>
      );
    }
    return this.props.children;
  }
}

// Redirects authenticated users away from auth routes
const RedirectIfAuthenticated: React.FC<{ redirectTo: string }> = ({ redirectTo }) => {
  const { isAuthenticated, role } = useAuth();
  const location = useLocation();

  if (isAuthenticated) {
    if (role === 'user') return <Navigate to="/user-dashboard" state={{ from: location }} replace />;
    if (role === 'admin') return <Navigate to="/admin/dashboard" state={{ from: location }} replace />;
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }

  return <Outlet />;
};

// PrivateRoute for user access control
const PrivateRoute: React.FC<{ children: React.ReactNode; role?: 'user' | 'admin' }> = ({ children, role }) => {
  const { isAuthenticated, role: userRole } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/signin" state={{ from: location }} replace />;
  }

  if (role && userRole !== role) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
};

const App: React.FC = () => {
  const { isAuthenticated, role } = useAuth();

  useEffect(() => {
    if (isAuthenticated && role === 'admin') {
      console.log('Admin session check performed by AdminAuthContext');
    } else if (isAuthenticated) {
      console.log('User session check performed by AuthContext');
    } else {
      console.log('Skipping session check: Not authenticated');
    }
  }, [isAuthenticated, role]);

  return (
    <AuthProvider>
      <AdminAuthProvider>
        <Router basename={import.meta.env.VITE_PUBLIC_URL || '/EmailNew'}>
          <div className="flex flex-col min-h-screen bg-gray-100">
            <main className="flex-grow">
              <div className="container mx-auto p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                  {/* Sidebar */}
                  <div className="lg:w-1/4 w-full bg-blue-600 text-white p-4 rounded-lg">
                    Sidebar or Navigation
                  </div>
                  {/* Main Content */}
                  <div className="lg:w-3/4 w-full bg-white p-4 rounded-lg shadow">
                    <ErrorBoundary>
                      <Suspense fallback={<div className="text-center p-6 text-gray-600">Loading...</div>}>
                        <Routes>
                          {/* User Auth Routes */}
                          <Route element={<RedirectIfAuthenticated redirectTo="/" />}>
                            <Route path="/signin" element={<SignIn />} />
                            <Route path="/signup" element={<SignUp />} />
                            <Route path="/verify-email" element={<VerifyEmail />} />
                            <Route path="/forgot-password" element={<ForgotPassword />} />
                            <Route path="/reset-password/:token" element={<ResetPassword />} />
                          </Route>

                          {/* Admin Auth Routes */}
                          <Route path="/admin" element={<AdminSignIn />} />
                          <Route path="/admin/signin" element={<AdminSignIn />} />
                          <Route path="/admin/signup" element={<AdminSignUp />} />

                          {/* Shared Logout Route */}
                          <Route path="/logout" element={<Logout />} />

                          {/* User Protected Routes */}
                          <Route
                            path="/"
                            element={
                              <PrivateRoute role="user">
                                <UserDashboard />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/user"
                            element={
                              <PrivateRoute role="user">
                                <UserDashboard />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/user-dashboard"
                            element={
                              <PrivateRoute role="user">
                                <UserDashboard />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/inbox"
                            element={
                              <PrivateRoute role="user">
                                <Inbox />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/profile"
                            element={
                              <PrivateRoute role="user">
                                <Profile />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/email/:id"
                            element={
                              <PrivateRoute role="user">
                                <EmailView />
                              </PrivateRoute>
                            }
                          />
                          <Route
                            path="/compose"
                            element={
                              <PrivateRoute role="user">
                                <ComposeEmail />
                              </PrivateRoute>
                            }
                          />

                          {/* Admin Protected Route */}
                          <Route
                            path="/admin/dashboard"
                            element={
                              <AdminProtectedRoute>
                                <AdminDashboard />
                              </AdminProtectedRoute>
                            }
                          />

                          {/* Unauthorized Fallback */}
                          <Route
                            path="/unauthorized"
                            element={
                              <div className="text-center mt-20">
                                <h2 className="text-2xl font-bold text-red-600">Unauthorized Access</h2>
                                <p className="text-gray-600">You do not have permission to view this page.</p>
                              </div>
                            }
                          />

                          <Route path="*" element={<Navigate to="/signin" replace />} />
                        </Routes>
                      </Suspense>
                    </ErrorBoundary>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </Router>
      </AdminAuthProvider>
    </AuthProvider>
  );
};

export default App;
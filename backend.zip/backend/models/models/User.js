// backend/models/User.js
import promisePool from '../config/db.js';
import bcrypt from 'bcryptjs';

// ✅ Create a new user
export const createUser = async ({
  id,
  firstName,
  lastName,
  email,
  password,
  role = 'user',
  isVerified = false,
  verificationToken = null
}) => {
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const defaultProfile = 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';

    const [result] = await promisePool.query(
      `INSERT INTO users 
       (id, firstName, lastName, email, password_hash, profilePicture, role, isVerified, verificationToken, isBlocked, isApproved, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, false, false, NOW(), NOW())`,
      [id, firstName, lastName, email, hashedPassword, defaultProfile, role, isVerified, verificationToken]
    );

    return {
      id,
      firstName,
      lastName,
      email,
      profilePicture: defaultProfile,
      role,
      isVerified
    };
  } catch (error) {
    console.error('Error creating user:', error);
    throw new Error('Failed to create user');
  }
};

// ✅ Get user by email (includes password_hash for login)
export const getUserByEmail = async (email) => {
  try {
    const [rows] = await promisePool.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    return rows[0] || null;
  } catch (error) {
    console.error('Error fetching user by email:', error);
    throw new Error('Failed to get user by email');
  }
};

// ✅ Get user by ID (excludes password_hash)
export const getUserById = async (id) => {
  try {
    console.log('Fetching user with ID:', id);
    const [rows] = await promisePool.query(
      `SELECT id, firstName, lastName, email, profilePicture, role, isVerified, lastLogin, isBlocked, isApproved, createdAt, approvedAt 
       FROM users WHERE id = ?`,
      [id]
    );
    console.log('User query result:', rows[0]);
    return rows[0] || null;
  } catch (error) {
    console.error('Error fetching user by ID:', error);
    throw new Error('Failed to get user by ID');
  }
};

// ✅ Update last login timestamp
export const updateLastLogin = async (userId) => {
  try {
    await promisePool.query('UPDATE users SET lastLogin = NOW() WHERE id = ?', [userId]);
  } catch (error) {
    console.error('Error updating last login:', error);
    throw new Error('Failed to update last login');
  }
};

// ✅ Compare password
export const matchPassword = async (enteredPassword, hashedPassword) => {
  try {
    return await bcrypt.compare(enteredPassword, hashedPassword);
  } catch (error) {
    console.error('Error comparing passwords:', error);
    throw new Error('Failed to compare passwords');
  }
};

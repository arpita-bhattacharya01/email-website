import promisePool from '../config/db.js';
import { v4 as uuidv4 } from 'uuid';

// Create a new email with attachments & labels
export async function createEmail({ senderId, recipientId, subject, body, folder = 'inbox', labels = [], attachments = [] }) {
  const id = uuidv4();

  await promisePool.query(
    `INSERT INTO emails (id, senderId, recipientId, subject, body, folder, labels, attachments, isRead, isStarred, isTrash, isDeleted, createdAt) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, false, false, false, false, NOW())`,
    [id, senderId, recipientId, subject, body, folder, JSON.stringify(labels), JSON.stringify(attachments)]
  );

  return { id };
}

// Fetch email by ID with labels & attachments
export async function getEmailById(emailId, userId = null) {
  const [rows] = await promisePool.query(
    `SELECT * FROM emails 
     WHERE id = ? AND isDeleted = false
     ${userId ? 'AND (senderId = ? OR recipientId = ?)' : ''}`,
    userId ? [emailId, userId, userId] : [emailId]
  );
  return rows[0] || null;
}

// Fetch emails by user and folder with filters
export async function getEmailsByUserId({ userId, folder = 'inbox', isRead, isStarred, search = '', limit = 20, offset = 0 }) {
  let conditions = [`(senderId = ? OR recipientId = ?)`, `folder = ?`, `isDeleted = false`];
  let params = [userId, userId, folder];

  if (typeof isRead === 'boolean') {
    conditions.push(`isRead = ?`);
    params.push(isRead);
  }

  if (typeof isStarred === 'boolean') {
    conditions.push(`isStarred = ?`);
    params.push(isStarred);
  }

  if (search) {
    conditions.push(`(subject LIKE ? OR body LIKE ?)`);
    params.push(`%${search}%`, `%${search}%`);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const query = `SELECT * FROM emails ${whereClause} ORDER BY createdAt DESC LIMIT ? OFFSET ?`;
  params.push(limit, offset);

  const [rows] = await promisePool.query(query, params);
  const [countResult] = await promisePool.query(
    `SELECT COUNT(*) as count FROM emails ${whereClause}`,
    params.slice(0, -2) // exclude limit/offset
  );

  return { emails: rows, totalCount: countResult[0].count };
}

// Mark email as read
export async function markAsRead(emailId) {
  const [result] = await promisePool.query(
    `UPDATE emails SET isRead = true WHERE id = ?`,
    [emailId]
  );
  return result.affectedRows > 0;
}

// Update flags (read/starred), folder, labels
export async function updateEmail(emailId, userId, updateData) {
  const { isRead, isStarred, folder, labels } = updateData;

  const [emailRows] = await promisePool.query(
    `SELECT * FROM emails WHERE id = ? AND recipientId = ?`,
    [emailId, userId]
  );
  if (emailRows.length === 0) return null;

  const updates = [];
  const params = [];

  if (typeof isRead === 'boolean') {
    updates.push('isRead = ?');
    params.push(isRead);
  }
  if (typeof isStarred === 'boolean') {
    updates.push('isStarred = ?');
    params.push(isStarred);
  }
  if (folder) {
    updates.push('folder = ?');
    params.push(folder);
  }
  if (labels) {
    updates.push('labels = ?');
    params.push(JSON.stringify(labels));
  }

  if (updates.length > 0) {
    await promisePool.query(
      `UPDATE emails SET ${updates.join(', ')} WHERE id = ? AND recipientId = ?`,
      [...params, emailId, userId]
    );
  }

  return getEmailById(emailId, userId);
}

// Move email to trash (soft move)
export async function moveToTrash(emailId, userId = null) {
  const [result] = await promisePool.query(
    `UPDATE emails SET isTrash = true, folder = 'trash' WHERE id = ? ${userId ? 'AND recipientId = ?' : ''}`,
    userId ? [emailId, userId] : [emailId]
  );
  return result.affectedRows > 0;
}

// Soft delete email
export async function deleteEmail(emailId, userId = null) {
  const [result] = await promisePool.query(
    `UPDATE emails SET isDeleted = true WHERE id = ? ${userId ? 'AND (senderId = ? OR recipientId = ?)' : ''}`,
    userId ? [emailId, userId, userId] : [emailId]
  );
  return result.affectedRows > 0;
}

// Star an email
export async function starEmail(emailId) {
  const [result] = await promisePool.query(
    `UPDATE emails SET isStarred = true WHERE id = ?`,
    [emailId]
  );
  return result.affectedRows > 0;
}

export default {
  createEmail,
  getEmailById,
  getEmailsByUserId,
  markAsRead,
  updateEmail,
  moveToTrash,
  deleteEmail,
  starEmail,
};

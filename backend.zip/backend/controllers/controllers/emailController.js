import * as Email from '../models/Email.js';
import * as User from '../models/User.js';

// Utility: Promisify getUserByEmail
const getUserByEmail = (email) => {
  return new Promise((resolve, reject) => {
    User.getUserByEmail(email, (err, user) => {
      if (err) return reject(err);
      resolve(user);
    });
  });
};

export const sendEmail = async (req, res, next) => {
  try {
    const { recipientEmail, subject, body, attachments = [], labels = [] } = req.body;

    const recipient = await getUserByEmail(recipientEmail);
    if (!recipient) {
      return res.status(404).json({ success: false, message: 'Recipient not found' });
    }

    const emailData = {
      senderId: req.user.id,
      recipientId: recipient.id,
      subject,
      body,
      attachments,
      labels
    };

    // Save to 'sent' folder
    await Email.createEmail({ ...emailData, folder: 'sent' });

    // Save to recipient's 'inbox'
    await Email.createEmail({ ...emailData, folder: 'inbox' });

    res.status(201).json({ success: true, message: 'Email sent successfully' });
  } catch (error) {
    next(error);
  }
};

export const getEmails = async (req, res, next) => {
  try {
    const { folder = 'inbox', page = 1, limit = 20, isRead, isStarred, search } = req.query;

    const filters = {
      userId: req.user.id,
      folder,
      isRead: isRead !== undefined ? isRead === 'true' : undefined,
      isStarred: isStarred !== undefined ? isStarred === 'true' : undefined,
      search,
      limit: parseInt(limit),
      offset: (parseInt(page) - 1) * parseInt(limit)
    };

    const { emails, totalCount } = await Email.getEmailsByUserId(filters);

    res.json({
      success: true,
      emails,
      totalCount,
      totalPages: Math.ceil(totalCount / filters.limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    next(error);
  }
};

export const getEmailById = async (req, res, next) => {
  try {
    const email = await Email.getEmailById(req.params.id, req.user.id);
    if (!email) {
      return res.status(404).json({ success: false, message: 'Email not found' });
    }

    // Mark as read if the current user is recipient and email isn't read
    if (email.recipientId === req.user.id && !email.isRead) {
      await Email.markAsRead(email.id);
      email.isRead = true;
    }

    res.json({ success: true, email });
  } catch (error) {
    next(error);
  }
};

export const updateEmail = async (req, res, next) => {
  try {
    const { isRead, isStarred, folder, labels } = req.body;

    const updatedEmail = await Email.updateEmail(
      req.params.id,
      req.user.id,
      { isRead, isStarred, folder, labels }
    );

    if (!updatedEmail) {
      return res.status(404).json({ success: false, message: 'Email not found' });
    }

    res.json({ success: true, email: updatedEmail });
  } catch (error) {
    next(error);
  }
};

export const trashEmail = async (req, res, next) => {
  try {
    const success = await Email.moveToTrash(req.params.id, req.user.id);
    if (!success) {
      return res.status(404).json({ success: false, message: 'Email not found' });
    }

    res.json({ success: true, message: 'Email moved to trash' });
  } catch (error) {
    next(error);
  }
};

export const deleteEmail = async (req, res, next) => {
  try {
    const success = await Email.deleteEmail(req.params.id, req.user.id);
    if (!success) {
      return res.status(404).json({ success: false, message: 'Email not found' });
    }

    res.json({ success: true, message: 'Email deleted successfully' });
  } catch (error) {
    next(error);
  }
};

import asyncHandler from 'express-async-handler';
import crypto from 'crypto';
import promisePool from '../config/db.js';
import { sendEmail } from './sendEmail.js';

// Generate a 6-digit numeric OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// @desc    Send OTP for email verification
// @route   POST /api/otp/send
export const sendOTP = asyncHandler(async (req, res) => {
  const { email } = req.body;

  if (!email) {
    res.status(400);
    throw new Error('Email is required');
  }

  const otp = generateOTP();
  const hashedOTP = crypto.createHash('sha256').update(otp).digest('hex');
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  // Delete any existing OTPs for this email
  await promisePool.query('DELETE FROM email_otps WHERE email = ?', [email]);

  // Store new OTP in DB
  await promisePool.query(
    'INSERT INTO email_otps (email, otp, expiresAt) VALUES (?, ?, ?)',
    [email, hashedOTP, expiresAt]
  );

  // Send OTP email
  const message = `
    <h2>Your OTP Code</h2>
    <p>Use the following OTP to verify your email:</p>
    <h3>${otp}</h3>
    <p>This OTP will expire in 10 minutes.</p>
  `;

  await sendEmail({
    to: email,
    subject: 'Email Verification OTP',
    html: message,
  });

  res.status(200).json({ success: true, message: 'OTP sent to email' });
});

// @desc    Verify OTP
// @route   POST /api/otp/verify
export const verifyOTP = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;

  if (!email || !otp) {
    res.status(400);
    throw new Error('Email and OTP are required');
  }

  const hashedOTP = crypto.createHash('sha256').update(otp).digest('hex');

  const [rows] = await promisePool.query(
    'SELECT * FROM email_otps WHERE email = ? AND otp = ? AND expiresAt > NOW()',
    [email, hashedOTP]
  );

  if (rows.length === 0) {
    res.status(400);
    throw new Error('Invalid or expired OTP');
  }

  // Clean up OTP record after successful verification
  await promisePool.query('DELETE FROM email_otps WHERE email = ?', [email]);

  res.status(200).json({ success: true, message: 'OTP verified successfully' });
});

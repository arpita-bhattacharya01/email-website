import dotenv from 'dotenv';
import db from '../config/db.js';
import nodemailer from 'nodemailer';
import { getUserByEmail } from '../models/User.js'; // ✅ Named import
import Email from '../models/Email.js';


dotenv.config();

// Setup nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Helper function to send the actual email via nodemailer
const sendMailViaNodemailer = async ({ to, subject, html }) => {
  const conn = await db.getConnection();
  let emailId;

  try {
    // Insert email record with pending status
    const [result] = await conn.query(
      `INSERT INTO emails (type, to_email, from_email, subject, body, status, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, NOW())`,
      ['sent', to, process.env.SMTP_USER, subject, html, 'pending']
    );
    emailId = result.insertId;

    // Send email
    const info = await transporter.sendMail({
      from: `"YourApp Support" <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });

    console.log(`✅ Email sent to ${to} | Message ID: ${info.messageId}`);

    // Mark email as sent
    await conn.query(
      `UPDATE emails SET status = ?, updated_at = NOW() WHERE email_id = ?`,
      ['sent', emailId]
    );
  } catch (error) {
    console.error('❌ Failed to send email:', error);

    if (emailId) {
      await conn.query(
        `UPDATE emails SET status = ?, error_message = ?, updated_at = NOW() WHERE email_id = ?`,
        ['failed', error.message, emailId]
      );
    }
    throw new Error('Email send failed');
  } finally {
    conn.release();
  }
};

// Controller function to handle email sending API
export const sendEmail = async (req, res, next) => {
  try {
    const { recipientEmail, subject, body, attachments = [], labels = [] } = req.body;

    if (!recipientEmail || !subject || !body) {
      return res.status(400).json({
        success: false,
        message: 'recipientEmail, subject, and body are required',
      });
    }

    // ✅ Get recipient user
    const recipient = await getUserByEmail(recipientEmail);
    if (!recipient) {
      return res.status(404).json({
        success: false,
        message: 'Recipient not found',
      });
    }

    // Create 'sent' email record
    const { id: senderEmailId } = await Email.createEmail({
      senderId: req.user.id,
      recipientId: recipient.id,
      subject,
      body,
      folder: 'sent',
      attachments,
      labels,
    });

    // Create 'inbox' email record
    const { id: recipientEmailId } = await Email.createEmail({
      senderId: req.user.id,
      recipientId: recipient.id,
      subject,
      body,
      folder: 'inbox',
      attachments,
      labels,
    });

    // Send the actual email
    await sendMailViaNodemailer({
      to: recipientEmail,
      subject,
      html: body,
    });

    return res.status(201).json({
      success: true,
      message: 'Email sent successfully',
      emailId: recipientEmailId,
    });
  } catch (error) {
    console.error('Error in sendEmail controller:', error);
    next(error);
  }
};

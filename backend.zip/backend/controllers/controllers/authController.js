import asyncHandler from 'express-async-handler';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import promisePool from '../config/db.js';
import { getUserByEmail, getUserById } from '../models/User.js';
import { sendEmail } from '../controllers/sendEmail.js';

// Generate JWT token and set HTTP-only cookie
const generateToken = (res, userId, role) => {
  const token = jwt.sign({ id: userId, role }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });

  res.cookie('accessToken', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 30 * 24 * 60 * 60 * 1000,
  });

  return token;
};

// Send verification email utility
const sendVerificationEmail = async (email, token) => {
  const url = `${process.env.VITE_API_URL || 'http://localhost:5173'}/verify-email/${token}`;
  const message = `
    <h2>Email Verification</h2>
    <p>Please click the link below to verify your email address:</p>
    <a href="${url}" target="_blank">${url}</a>
  `;

  await sendEmail({
    to: email,
    subject: 'Verify Your Email',
    html: message,
  });
};

// @desc    Register user
// @route   POST /api/signup
export const registerUser = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, confirmPassword } = req.body;

  if (!firstName || !lastName || !email || !password || !confirmPassword) {
    res.status(400);
    throw new Error('All fields are required');
  }

  if (password !== confirmPassword) {
    res.status(400);
    throw new Error('Passwords do not match');
  }

  if (password.length < 8 || !/^(?=.*[a-zA-Z])(?=.*\d)/.test(password)) {
    res.status(400);
    throw new Error('Password must be at least 8 characters and include at least one letter and one number');
  }

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
  if (!emailRegex.test(email) || (email.match(/\d/g) || []).length < 4) {
    res.status(400);
    throw new Error('Email must be valid and include at least 4 digits');
  }

  const existingUser = await getUserByEmail(email);
  if (existingUser) {
    res.status(400);
    throw new Error('User already exists');
  }

  const id = uuidv4();
  const hashedPassword = await bcrypt.hash(password, 10);
  const verificationToken = crypto.randomBytes(32).toString('hex');

  await promisePool.query(
    `INSERT INTO users (id, firstName, lastName, email, password_hash, isVerified, verificationToken, role, isBlocked, isApproved, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
    [id, firstName, lastName, email, hashedPassword, false, verificationToken, 'user', false, false]
  );

  await sendVerificationEmail(email, verificationToken);

  res.status(201).json({
    success: true,
    message: 'User registered successfully. Please verify your email.',
    user: {
      id,
      firstName,
      lastName,
      email,
      isVerified: false,
      role: 'user',
    },
  });
});

// @desc    Verify email
// @route   GET /api/verify-email/:token
export const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.params;

  const [rows] = await promisePool.query(
    'SELECT * FROM users WHERE verificationToken = ?',
    [token]
  );

  if (rows.length === 0) {
    res.status(400);
    throw new Error('Invalid or expired verification token');
  }

  const user = rows[0];

  await promisePool.query(
    `UPDATE users 
     SET isVerified = 1, verificationToken = NULL, isApproved = 1, approvedAt = NOW() 
     WHERE id = ?`,
    [user.id]
  );

  await sendEmail({
    to: user.email,
    subject: 'Welcome!',
    html: `<p>Hi ${user.firstName}, your email has been successfully verified.</p>`,
  });

  const authToken = generateToken(res, user.id, user.role || 'user');

  res.status(200).json({
    success: true,
    message: 'Email verified successfully',
    user: {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      isVerified: true,
      role: user.role || 'user',
    },
    token: authToken,
  });
});

// @desc    Login user
// @route   POST /api/signin
export const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await getUserByEmail(email);

  if (!user) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  if (!user.isVerified) {
    res.status(401);
    throw new Error('Please verify your email before logging in');
  }

  if (user.isBlocked) {
    res.status(403);
    throw new Error('Your account is blocked');
  }

  const isMatch = await bcrypt.compare(password, user.password_hash);
  if (!isMatch) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  const token = generateToken(res, user.id, user.role || 'user');

  await promisePool.query('UPDATE users SET lastLogin = NOW() WHERE id = ?', [user.id]);

  res.status(200).json({
    success: true,
    user: {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      isVerified: Boolean(user.isVerified),
      role: user.role || 'user',
    },
    token,
  });
});

// @desc    Logout user
// @route   POST /api/logout
export const logoutUser = asyncHandler(async (req, res) => {
  res.cookie('accessToken', '', {
    httpOnly: true,
    expires: new Date(0),
  });

  res.status(200).json({ success: true, message: 'Logged out successfully' });
});

// @desc    Get user profile
// @route   GET /api/user
export const getUserProfile = asyncHandler(async (req, res) => {
  const user = await getUserById(req.user.id);

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  res.status(200).json({
    success: true,
    user: {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      isVerified: Boolean(user.isVerified),
      role: user.role || 'user',
    },
  });
});

// @desc    Update user profile
// @route   PUT /api/user
export const updateProfile = asyncHandler(async (req, res) => {
  const { firstName, lastName } = req.body;

  const user = await getUserById(req.user.id);

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  await promisePool.query(
    'UPDATE users SET firstName = ?, lastName = ?, updatedAt = NOW() WHERE id = ?',
    [firstName || user.firstName, lastName || user.lastName, user.id]
  );

  const updatedUser = await getUserById(user.id);

  res.status(200).json({
    success: true,
    user: {
      id: updatedUser.id,
      firstName: updatedUser.firstName,
      lastName: updatedUser.lastName,
      email: updatedUser.email,
      isVerified: Boolean(updatedUser.isVerified),
      role: updatedUser.role || 'user',
    },
  });
});

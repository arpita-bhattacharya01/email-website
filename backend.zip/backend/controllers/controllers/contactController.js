import sendEmail from '../utils/sendEmail.js';

const contactUs = async (req, res) => {
  const { name, email, message } = req.body;

  const htmlContent = `
    <h1>New Contact Request</h1>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Message:</strong><br/>${message}</p>
  `;

  try {
    await sendEmail({
      to: 'admin1234@yourdomain.com',
      subject: 'New Contact Form Submission',
      html: htmlContent,
    });

    res.status(200).json({ success: true, message: 'Email sent successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to send email' });
  }
};

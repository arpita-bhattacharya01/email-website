// backend/config/db.js
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load environment variables from .env file in the backend folder
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const envPath = path.resolve(__dirname, '../.env');
const result = dotenv.config({ path: envPath });

if (result.error) {
  console.error('❌ Failed to load .env file:', result.error.message);
  process.exit(1);
}

console.log('🔧 Environment variables:', {
  DB_HOST: process.env.DB_HOST,
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD ? '[REDACTED]' : undefined,
  DB_NAME: process.env.DB_NAME,
  DB_PORT: process.env.DB_PORT,
  ENV_PATH: envPath,
});

// Validate required DB variables
const requiredVars = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME', 'DB_PORT'];
for (const key of requiredVars) {
  if (!process.env[key]) {
    console.error(`❌ Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

// Global pool reference
let promisePool = null;

// Create and test pool
async function createPool() {
  try {
    const pool = mysql.createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: Number(process.env.DB_PORT),
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      connectTimeout: 10000
    });

    // Verify connection
    const connection = await pool.getConnection();
    await connection.ping();
    connection.release();

    console.log('✅ MySQL pool created and connection verified');
    return pool;
  } catch (error) {
    console.error('❌ Error creating MySQL pool or connecting:', {
      message: error.message,
      code: error.code,
      errno: error.errno,
      sqlState: error.sqlState,
      stack: error.stack,
    });
    process.exit(1);
  }
}

// Handle connection loss and reconnect
async function handleDisconnect() {
  if (promisePool) return; // Prevent double creation

  promisePool = await createPool();

  promisePool.on('error', async (err) => {
    console.error('❌ MySQL pool error:', err);
    if (err.code === 'PROTOCOL_CONNECTION_LOST' || err.fatal) {
      console.log('🔁 Reconnecting to MySQL...');
      promisePool = null;
      await handleDisconnect();
    } else {
      throw err;
    }
  });
}

// Initialize pool
await handleDisconnect();

// Export default pool
export default promisePool;

// Optional helper for custom queries
export async function getConnection() {
  if (!promisePool) {
    console.log('⏳ No DB pool found, reconnecting...');
    await handleDisconnect();
  }
  const conn = await promisePool.getConnection();
  console.log('🔗 DB connection retrieved from pool');
  return conn;
}

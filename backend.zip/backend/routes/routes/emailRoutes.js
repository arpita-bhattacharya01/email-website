import express from 'express';
import {
  sendEmail,
  getEmails,
  getEmailById as getEmailByIdController,
  updateEmail,
  trashEmail as trashEmailController,
  deleteEmail as deleteEmailController
} from '../controllers/emailController.js';

import {
  createEmail,
  getEmailById as getEmailByIdModel,
  getEmailsByUserId,
  markAsRead,
  starEmail,
  moveToTrash,
  deleteEmail as deleteEmailModel
} from '../models/Email.js';

import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Apply protect middleware to all routes
router.use(protect);

//
// ===============================
// 🚀 Model-Based Custom Routes
// ===============================
// These routes use model functions directly and must come before dynamic :id routes

// Create and send a new email
router.post('/send', async (req, res) => {
  try {
    const id = await createEmail(req.body);
    res.json({ success: true, message: 'Email sent successfully', id });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get email by ID using model
router.get('/model/:id', async (req, res) => {
  try {
    const email = await getEmailByIdModel(req.params.id);
    res.json(email);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get emails by user ID and folder (inbox, sent, trash, etc.)
router.get('/user/:userId', async (req, res) => {
  try {
    const folder = req.query.folder || 'inbox';
    const emails = await getEmailsByUserId(req.params.userId, folder);
    res.json(emails);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Mark email as read
router.post('/:id/read', async (req, res) => {
  try {
    const success = await markAsRead(req.params.id);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Star/unstar email
router.post('/:id/star', async (req, res) => {
  try {
    const success = await starEmail(req.params.id);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Move email to trash (model-based)
router.post('/:id/trash-model', async (req, res) => {
  try {
    const success = await moveToTrash(req.params.id);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Permanently delete email (model-based)
router.delete('/:id/model', async (req, res) => {
  try {
    const success = await deleteEmailModel(req.params.id);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

//
// ===============================
// 📦 Controller-Based Routes
// ===============================

// Create email (same as model route but via controller)
router.post('/', async (req, res) => {
  try {
    await sendEmail(req, res);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get all emails (controller logic)
router.get('/', async (req, res) => {
  try {
    await getEmails(req, res);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Move to trash (controller logic)
router.put('/:id/trash', async (req, res) => {
  try {
    await trashEmailController(req, res);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Email by ID - supports GET, PUT, DELETE via controller
router.route('/:id')
  .get(async (req, res) => {
    try {
      await getEmailByIdController(req, res);
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  })
  .put(async (req, res) => {
    try {
      await updateEmail(req, res);
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  })
  .delete(async (req, res) => {
    try {
      await deleteEmailController(req, res);
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

export default router;

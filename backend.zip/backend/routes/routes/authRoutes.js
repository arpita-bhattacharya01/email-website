import express from 'express';
import {
  registerUser,
  loginUser,
  logoutUser,
  verifyEmail,
  getUserProfile,
  updateProfile,
} from '../controllers/authController.js';
import { protect, authorizeRoles } from '../middleware/authMiddleware.js';

const router = express.Router();

/** 🔓 Public Routes */
router.post('/signup', registerUser);                // Register a new user
router.post('/signin', loginUser);                   // Login user
router.get('/verify-email/:token', verifyEmail);     // Email verification
router.post('/logout', logoutUser);                  // Logout user
router.get('/public', (req, res) => res.send('Public route')); // Test route

/** 🔐 Protected Routes (User) */
router.get('/user', protect, getUserProfile);        // Get user profile
router.put('/user', protect, updateProfile);         // Update user profile
router.get('/me', protect, getUserProfile);          // Alias to /user (optional)

/** 🔐 Admin Routes */
router.get('/admin', protect, authorizeRoles('admin'), (req, res) => {
  res.send('Welcome, Admin!');
});

export default router;

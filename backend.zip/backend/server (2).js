import express from 'express';
import mysql from 'mysql2/promise';
import bcrypt from 'bcrypt';
import multer from 'multer';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import nodemailer from 'nodemailer';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';
import 'dotenv/config';

import promisePool from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import adminUsersRoutes from './routes/adminUsers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const app = express();

app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());

// File upload
const storage = multer.diskStorage({
  destination: join(__dirname, 'Uploads'),
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage });

// Nodemailer setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});
transporter.verify((err) => {
  if (err) console.error('❌ SMTP connection error:', err);
  else console.log('✅ Nodemailer SMTP connected.');
});

// Check MySQL
async function verifyDatabaseConnection() {
  try {
    const connection = await promisePool.getConnection();
    console.log('✅ MySQL connected.');
    connection.release();
  } catch (err) {
    console.error('❌ MySQL error:', err.message);
    process.exit(1);
  }
}

// Auth middleware
async function authenticateUser(req, res, next) {
  const { senderId } = req.body;
  if (!senderId) return res.status(401).json({ message: 'Missing senderId' });

  try {
    const [rows] = await promisePool.query('SELECT id FROM users WHERE id = ?', [senderId]);
    if (!rows.length) return res.status(401).json({ message: 'Invalid senderId' });
    next();
  } catch (err) {
    console.error('❌ Auth middleware error:', err);
    res.status(500).json({ message: 'Auth failed' });
  }
}

// Send email
app.post('/api/emails', authenticateUser, upload.array('files'), async (req, res) => {
  const { senderId, recipientId, subject, body, folder = 'sent' } = req.body;
  const files = req.files;

  const connection = await promisePool.getConnection();
  try {
    await connection.beginTransaction();

    const [[sender]] = await connection.query('SELECT email FROM users WHERE id = ?', [senderId]);
    const senderEmail = sender?.email || '';

    const attachments = files?.map(file => ({
      filename: file.originalname,
      path: file.path,
    }));

    await connection.execute(
      `INSERT INTO emails 
        (id, senderId, recipientId, subject, body, folder, attachments, isRead, isStarred, isTrash, isDeleted) 
       VALUES (?, ?, ?, ?, ?, ?, ?, FALSE, FALSE, FALSE, FALSE)`,
      [
        uuidv4(),
        senderId,
        recipientId,
        subject,
        body,
        folder,
        JSON.stringify(attachments || [])
      ]
    );

    await transporter.sendMail({
      from: `"App Mailer" <${senderEmail}>`,
      to: recipientId, // assuming this resolves to an email
      subject,
      text: body,
      attachments: attachments || [],
    });

    await connection.commit();
    res.status(200).json({ message: 'Email sent successfully' });
  } catch (err) {
    await connection.rollback();
    console.error('❌ Send mail error:', err);
    res.status(500).json({ message: 'Failed to send email' });
  } finally {
    connection.release();
  }
});

// Send OTP
app.post('/api/send-otp', async (req, res) => {
  const { email } = req.body;
  try {
    const [user] = await promisePool.query('SELECT email FROM users WHERE email = ?', [email]);
    if (user.length) return res.status(409).json({ message: 'Email already registered' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    await promisePool.query(
      'INSERT INTO otps (email, otp, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))',
      [email, otp]
    );

    await transporter.sendMail({
      from: `"App Auth" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: 'Your OTP Code',
      text: `Use this OTP: ${otp}. It expires in 10 minutes.`,
    });

    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (err) {
    console.error('❌ OTP error:', err);
    res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// Verify OTP
app.post('/api/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  try {
    const [rows] = await promisePool.query(
      'SELECT * FROM otps WHERE email = ? AND otp = ? AND expires_at > NOW()',
      [email, otp]
    );

    if (!rows.length) return res.status(400).json({ message: 'Invalid or expired OTP' });

    await promisePool.query('DELETE FROM otps WHERE email = ?', [email]);
    res.status(200).json({ message: 'OTP verified' });
  } catch (err) {
    console.error('❌ Verify OTP error:', err);
    res.status(500).json({ message: 'OTP verification failed' });
  }
});

// Auth
app.use('/api/signup', authRoutes);
app.post('/api/signin', async (req, res) => {
  const { email, password } = req.body;
  try {
    const [rows] = await promisePool.query('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    res.status(200).json({
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      },
    });
  } catch (err) {
    console.error('❌ Login error:', err);
    res.status(500).json({ message: 'Login failed' });
  }
});

app.use('/api/admin', adminUsersRoutes);

const PORT = process.env.PORT || 5000;
async function startServer() {
  await verifyDatabaseConnection();
  app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
}
startServer();

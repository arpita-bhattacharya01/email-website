import express from 'express';
import mysql from 'mysql2/promise';
import bcrypt from 'bcrypt';
import multer from 'multer';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import nodemailer from 'nodemailer';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import 'dotenv/config';
import otpRoutes from './routes/otpRoutes.js';
import authRoutes from './routes/authRoutes.js';
import adminUsersRoutes from './routes/adminUsers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const app = express();

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'email',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Check MySQL connection
async function verifyDatabaseConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ MySQL connected. Config:', {
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT
    });
    connection.release();
  } catch (err) {
    console.error('❌ MySQL error:', err.message);
    process.exit(1);
  }
}

// Middleware
app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());

// File upload
const storage = multer.diskStorage({
  destination: join(__dirname, 'Uploads'),
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage });

// Nodemailer setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});
transporter.verify((err) => {
  if (err) console.error('❌ SMTP connection error:', err);
  else console.log('✅ Nodemailer SMTP connected.');
});

// Auth middleware
async function authenticateUser(req, res, next) {
  const { senderId } = req.body;
  if (!senderId) return res.status(401).json({ message: 'Missing senderId' });

  try {
    const [rows] = await pool.query('SELECT id FROM users WHERE id = ?', [senderId]);
    if (!rows.length) return res.status(401).json({ message: 'Invalid senderId' });
    next();
  } catch (err) {
    console.error('❌ Auth middleware error:', err);
    res.status(500).json({ message: 'Auth failed' });
  }
}

// Send email
app.post('/api/emails', authenticateUser, upload.array('files'), async (req, res) => {
  const { senderId, recipientId, subject, body, folder = 'sent' } = req.body;
  const files = req.files;

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [[sender]] = await connection.query('SELECT email FROM users WHERE id = ?', [senderId]);
    const senderEmail = sender?.email || '';

    const attachments = files?.map(file => ({
      filename: file.originalname,
      path: file.path,
    }));

    await connection.execute(
      `INSERT INTO emails 
        (id, senderId, recipientId, subject, body, folder, attachments, isRead, isStarred, isTrash, isDeleted) 
       VALUES (?, ?, ?, ?, ?, ?, ?, FALSE, FALSE, FALSE, FALSE)`,
      [
        uuidv4(),
        senderId,
        recipientId,
        subject,
        body,
        folder,
        JSON.stringify(attachments || [])
      ]
    );

    await transporter.sendMail({
      from: `"App Mailer" <${senderEmail}>`,
      to: recipientId, // assuming this resolves to an email
      subject,
      text: body,
      attachments: attachments || [],
    });

    await connection.commit();
    res.status(200).json({ message: 'Email sent successfully' });
  } catch (err) {
    await connection.rollback();
    console.error('❌ Send mail error:', err);
    res.status(500).json({ message: 'Failed to send email' });
  } finally {
    connection.release();
  }
});

// Send OTP
app.post('/api/send-otp', async (req, res) => {
  const { email } = req.body;
  try {
    const [user] = await pool.query('SELECT email FROM users WHERE email = ?', [email]);
    if (user.length) return res.status(409).json({ message: 'Email already registered' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    await pool.query(
      'INSERT INTO otps (email, otp, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))',
      [email, otp]
    );

    await transporter.sendMail({
      from: `"App Auth" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: 'Your OTP Code',
      text: `Use this OTP: ${otp}. It expires in 10 minutes.`,
    });

    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (err) {
    console.error('❌ OTP error:', err);
    res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// Verify OTP
app.post('/api/verify-otp', async (req, res) => {
  const { email, otp } = req.body;
  try {
    const [rows] = await pool.query(
      'SELECT * FROM otps WHERE email = ? AND otp = ? AND expires_at > NOW()',
      [email, otp]
    );

    if (!rows.length) return res.status(400).json({ message: 'Invalid or expired OTP' });

    await pool.query('DELETE FROM otps WHERE email = ?', [email]);
    res.status(200).json({ message: 'OTP verified' });
  } catch (err) {
    console.error('❌ Verify OTP error:', err);
    res.status(500).json({ message: 'OTP verification failed' });
  }
});

// Sign-in route
app.post('/api/signin', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'your_jwt_secret', { expiresIn: '1h' });
    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      },
      token,
    });
  } catch (error) {
    console.error('Sign-in error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Routes
app.use('/api', authRoutes);
app.use('/api/admin', adminUsersRoutes);
app.use('/api/otp', otpRoutes);

const PORT = process.env.PORT || 5000;
async function startServer() {
  await verifyDatabaseConnection();
  app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
}
startServer();

// Export pool for use in routes
export const dbPool = pool;
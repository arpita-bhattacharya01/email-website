import jwt from 'jsonwebtoken';
import asyncHandler from 'express-async-handler';
import {
  getUserById,
  getRefreshTokenByToken,
  saveRefreshToken,
  deleteRefreshTokenByUserId
} from '../models/User.js';
import promisePool from '../config/db.js'; // Corrected import path

// Helper: generate access token
export const generateAccessToken = (user) => {
  return jwt.sign(
    { id: user.id, role: user.role || 'user' },
    process.env.JWT_SECRET || 'secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '1d' }
  );
};

// Helper: generate refresh token
export const generateRefreshToken = (user) => {
  return jwt.sign(
    { id: user.id },
    process.env.JWT_REFRESH_SECRET || 'refresh_secret',
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  );
};

// Middleware to protect routes using access token
export const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Log request details for debugging
  console.log(`Protect middleware called for: ${req.url}`);
  console.log('Headers:', req.headers);
  console.log('Cookies:', req.cookies);

  // Extract token from Authorization header or cookie
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer ')
  ) {
    token = req.headers.authorization.split(' ')[1];
    console.log('Token from Authorization header:', token);
  } else if (req.cookies && req.cookies.accessToken) {
    token = req.cookies.accessToken;
    console.log('Token from cookies:', token);
  }

  if (!token) {
    console.log('No token provided');
    return res.status(401).json({
      success: false,
      message: 'Not authorized, no access token provided',
    });
  }

  try {
    // Verify JWT_SECRET exists
    if (!process.env.JWT_SECRET) {
      console.error('JWT_SECRET is not defined in environment variables');
      return res.status(500).json({
        success: false,
        message: 'Server configuration error: JWT_SECRET missing',
      });
    }

    // Verify token
    console.log('Verifying token with JWT_SECRET:', process.env.JWT_SECRET);
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log('Decoded token:', decoded);

    // Validate database connection
    try {
      await promisePool.query('SELECT 1'); // Using promisePool
      console.log('Database connection validated');
    } catch (dbError) {
      console.error('Database connection error:', dbError.message);
      return res.status(503).json({
        success: false,
        message: 'Database connection failed, please try again later',
      });
    }

    // Fetch user with timeout
    const user = await Promise.race([
      getUserById(decoded.id),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Database query timeout')), 5000)
      ),
    ]);
    console.log('User from getUserById:', user);

    if (!user) {
      console.log('User not found for ID:', decoded.id);
      return res.status(401).json({
        success: false,
        message: 'Not authorized, user not found',
      });
    }

    req.user = {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role || 'user',
    };
    console.log('req.user set:', req.user);

    next();
  } catch (error) {
    console.error('Protect middleware error:', error.message);
    if (error.message === 'Database query timeout') {
      return res.status(503).json({
        success: false,
        message: 'Database query timeout, please try again later',
      });
    }
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: `Not authorized, token verification failed: ${error.message}`,
      });
    }
    return res.status(500).json({
      success: false,
      message: `Server error: ${error.message}`,
    });
  }
});

// Role-based authorization middleware
export const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Role '${req.user?.role || 'unknown'}' is not authorized for this route`,
      });
    }
    next();
  };
};

// Simple access token authentication middleware
export const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ success: false, message: 'Token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'secret', (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Middleware to handle refresh token and issue new access token
export const handleRefreshToken = asyncHandler(async (req, res) => {
  const refreshToken =
    req.cookies?.refreshToken || req.body.refreshToken || req.headers['x-refresh-token'];
  if (!refreshToken) {
    return res.status(401).json({ success: false, message: 'Refresh token required' });
  }

  try {
    // Verify refresh token signature and expiration
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'refresh_secret');

    // Check if refresh token exists in DB
    const savedToken = await getRefreshTokenByToken(refreshToken);
    if (!savedToken || savedToken.userId !== decoded.id) {
      return res.status(401).json({ success: false, message: 'Invalid refresh token' });
    }

    const user = await getUserById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found' });
    }

    // Rotate refresh token: create new token and replace old
    const newRefreshToken = generateRefreshToken(user);
    await saveRefreshToken(user.id, newRefreshToken);
    await deleteRefreshTokenByUserId(user.id, refreshToken);

    // Generate new access token
    const newAccessToken = generateAccessToken(user);

    // Set new refresh token cookie
    res.cookie('refreshToken', newRefreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days (corrected typo from 'maxAge')
    });

    // Set new access token cookie
    res.cookie('accessToken', newAccessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000, // 1 day (corrected typo from 'maxAge')
    });

    // Respond with tokens and user info
    return res.status(200).json({
      success: true,
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role || 'user',
      },
    });
  } catch (err) {
    console.error('Refresh token error:', err);
    return res.status(401).json({ success: false, message: 'Invalid or expired refresh token' });
  }
});
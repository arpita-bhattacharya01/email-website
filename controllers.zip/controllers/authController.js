import asyncHandler from 'express-async-handler';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { OAuth2Client } from 'google-auth-library';
import { sendEmail } from './emailController.js'; // Added .js extension

// Validate environment variables
const requiredEnvVars = [
  'JWT_SECRET',
  'REFRESH_TOKEN_SECRET',
  'JWT_EXPIRES_IN',
  'REFRESH_TOKEN_EXPIRES_IN',
  'CLIENT_URL',
  'SMTP_HOST',
  'SMTP_PORT',
  'SMTP_USER',
  'SMTP_PASS',
  'GOOGLE_CLIENT_ID',
];
const missingVars = requiredEnvVars.filter((varName) => !process.env[varName]);
if (missingVars.length > 0) {
  throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
}

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Generate Access Token and set cookie
const generateAccessToken = (res, userId, role) => {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET environment variable is not defined');
  }
  const token = jwt.sign(
    { id: userId, role },
    process.env.JWT_SECRET,
    {
      expiresIn: process.env.JWT_EXPIRES_IN,
    }
  );

  res.cookie('authToken', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 24 * 60 * 60 * 1000, // 1 day
  });

  return token;
};

// Generate Refresh Token and store in DB
const generateRefreshToken = async (pool, userId) => {
  const refreshToken = crypto.randomBytes(40).toString('hex');
  const expiresIn = parseInt(process.env.REFRESH_TOKEN_EXPIRES_IN || '604800000', 10); // Default 7 days
  const expiresAt = new Date(Date.now() + expiresIn);

  try {
    await pool.query('DELETE FROM refresh_tokens WHERE user_id = ? AND expires_at < NOW()', [userId]);
    await pool.query(
      'INSERT INTO refresh_tokens (user_id, token, created_at, expires_at) VALUES (?, ?, NOW(), ?)',
      [userId, refreshToken, expiresAt]
    );
    return refreshToken;
  } catch (error) {
    throw new Error(`Failed to generate refresh token: ${error.message}`);
  }
};

// Verify Refresh Token
const verifyRefreshToken = async (pool, token) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM refresh_tokens WHERE token = ? AND expires_at > NOW()',
      [token]
    );
    return rows[0] || null;
  } catch (error) {
    throw new Error(`Failed to verify refresh token: ${error.message}`);
  }
};

// Delete Refresh Token
const deleteRefreshToken = async (pool, token) => {
  try {
    await pool.query('DELETE FROM refresh_tokens WHERE token = ?', [token]);
  } catch (error) {
    throw new Error(`Failed to delete refresh token: ${error.message}`);
  }
};

// Shared sign-in logic
const performSignIn = async (pool, res, email, password, isAdmin) => {
  if (!email || !password) {
    res.status(400);
    throw new Error('Email and password are required');
  }

  const [rows] = await pool.query(
    isAdmin
      ? 'SELECT * FROM users WHERE email = ? AND role = ?'
      : 'SELECT * FROM users WHERE email = ?',
    isAdmin ? [email, 'admin'] : [email]
  );
  const user = rows[0];
  if (!user) {
    res.status(401);
    throw new Error(isAdmin ? 'Invalid admin credentials' : 'Invalid email or password');
  }
  if (user.isBlocked) {
    res.status(403);
    throw new Error('Account is blocked');
  }
  if (!isAdmin && !user.isVerified) {
    res.status(401);
    throw new Error('Please verify your email before logging in');
  }
  if (!isAdmin && !user.isApproved) {
    res.status(403);
    throw new Error('Account not approved');
  }
  if (!(await bcrypt.compare(password, user.password_hash))) {
    res.status(401);
    throw new Error(isAdmin ? 'Invalid admin credentials' : 'Invalid email or password');
  }

  try {
    const accessToken = generateAccessToken(res, user.id, user.role);
    const refreshToken = await generateRefreshToken(pool, user.id);

    await pool.query('UPDATE users SET lastLogin = NOW() WHERE id = ?', [user.id]);

    res.status(200).json({
      success: true,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        isVerified: !!user.isVerified,
        role: user.role,
        isBlocked: !!user.isBlocked,
        isApproved: !!user.isApproved,
      },
      token: accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error(`${isAdmin ? 'Admin signin' : 'Signin'} error:`, error);
    res.status(500);
    throw new Error(`Failed to log in${isAdmin ? ' as admin' : ''}`);
  }
};

// Shared logout logic
const performLogout = async (pool, res, refreshToken, isAdmin) => {
  try {
    if (refreshToken) {
      await deleteRefreshToken(pool, refreshToken);
    }
    res.clearCookie('authToken');
    res.status(200).json({ success: true, message: `${isAdmin ? 'Admin' : 'User'} logged out successfully` });
  } catch (error) {
    console.error(`${isAdmin ? 'Admin logout' : 'Logout'} error:`, error);
    res.status(500);
    throw new Error(`Failed to log out${isAdmin ? ' admin' : ''}`);
  }
};

const signup = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, confirmPassword } = req.body;
  if (!firstName || !lastName || !email || !password || !confirmPassword) {
    res.status(400);
    throw new Error('All fields are required');
  }
  if (password !== confirmPassword) {
    res.status(400);
    throw new Error('Passwords do not match');
  }
  if (password.length < 8 || !/^(?=.*[a-zA-Z])(?=.*\d)/.test(password)) {
    res.status(400);
    throw new Error('Password must be at least 8 characters and include one letter and one number');
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
  const digitCount = (email.match(/\d/g) || []).length;
  if (!emailRegex.test(email)) {
    res.status(400);
    throw new Error('Invalid email format');
  }
  if (digitCount < 4) {
    res.status(400);
    throw new Error('Email must include at least 4 digits');
  }

  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }

  const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (rows[0]) {
    res.status(400);
    throw new Error('Email already exists');
  }

  const id = uuidv4();
  const hashedPassword = await bcrypt.hash(password, 10);
  const verificationToken = crypto.randomBytes(32).toString('hex');

  try {
    await pool.query(
      'INSERT INTO users (id, firstName, lastName, email, password_hash, verificationToken, role, isBlocked, isApproved, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
      [id, firstName, lastName, email, hashedPassword, verificationToken, 'user', false, false]
    );

    const verificationUrl = `${process.env.CLIENT_URL}/verify-email/${verificationToken}`;
    await sendEmail({
      to: email,
      subject: 'Verify Your Email',
      html: `<p>Please verify your email by clicking <a href="${verificationUrl}">here</a>.</p>`,
    });

    res.status(201).json({
      success: true,
      message: 'User registered successfully. Please verify your email.',
      user: { id, firstName, lastName, email, isVerified: false, role: 'user' },
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500);
    throw new Error('Failed to register user');
  }
});

const signin = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  await performSignIn(pool, res, req.body.email, req.body.password, false);
});

const adminSignup = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  if (!firstName || !lastName || !email || !password) {
    res.status(400);
    throw new Error('All fields are required');
  }
  if (password.length < 8 || !/^(?=.*[a-zA-Z])(?=.*\d)/.test(password)) {
    res.status(400);
    throw new Error('Password must be at least 8 characters and include one letter and one number');
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
  if (!emailRegex.test(email)) {
    res.status(400);
    throw new Error('Invalid email format');
  }

  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }

  const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (rows[0]) {
    res.status(400);
    throw new Error('Email already exists');
  }

  const id = uuidv4();
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    await pool.query(
      'INSERT INTO users (id, firstName, lastName, email, password_hash, role, isVerified, isApproved, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
      [id, firstName, lastName, email, hashedPassword, 'admin', true, true]
    );
    res.status(201).json({ success: true, message: 'Admin created successfully' });
  } catch (error) {
    console.error('Admin signup error:', error);
    res.status(500);
    throw new Error('Admin signup failed');
  }
});

const adminSignin = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  await performSignIn(pool, res, req.body.email, req.body.password, true);
});

const logoutUser = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  await performLogout(pool, res, req.body.refreshToken, false);
});

const adminLogout = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  await performLogout(pool, res, req.body.refreshToken, true);
});

const getUserProfile = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  if (!req.user?.id) {
    res.status(401);
    throw new Error('User not authenticated');
  }

  try {
    const [rows] = await pool.query(
      'SELECT id, firstName, lastName, email, role, isVerified, isBlocked, isApproved FROM users WHERE id = ?',
      [req.user.id]
    );
    const user = rows[0];
    if (!user) {
      res.status(404);
      throw new Error('User not found');
    }
    res.status(200).json({
      success: true,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        isVerified: !!user.isVerified,
        role: user.role,
        isBlocked: !!user.isBlocked,
        isApproved: !!user.isApproved,
      },
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500);
    throw new Error('Failed to fetch user profile');
  }
});

const updateProfile = asyncHandler(async (req, res) => {
  const { firstName, lastName, email } = req.body;
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  if (!req.user?.id) {
    res.status(401);
    throw new Error('User not authenticated');
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
    const user = rows[0];
    if (!user) {
      res.status(404);
      throw new Error('User not found');
    }

    const newEmail = email || user.email;
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
    const digitCount = (newEmail.match(/\d/g) || []).length;
    if (!emailRegex.test(newEmail)) {
      res.status(400);
      throw new Error('Invalid email format');
    }
    if (digitCount < 4) {
      res.status(400);
      throw new Error('Email must include at least 4 digits');
    }

    const [emailCheck] = await pool.query('SELECT id FROM users WHERE email = ? AND id != ?', [
      newEmail,
      req.user.id,
    ]);
    if (emailCheck[0]) {
      res.status(400);
      throw new Error('Email already exists');
    }

    await pool.query(
      'UPDATE users SET firstName = ?, lastName = ?, email = ?, updatedAt = NOW() WHERE id = ?',
      [firstName || user.firstName, lastName || user.lastName, newEmail, req.user.id]
    );

    const [updatedRows] = await pool.query(
      'SELECT id, firstName, lastName, email, role, isVerified, isBlocked, isApproved FROM users WHERE id = ?',
      [req.user.id]
    );
    const updatedUser = updatedRows[0];

    res.status(200).json({
      success: true,
      user: {
        id: updatedUser.id,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        email: updatedUser.email,
        isVerified: !!updatedUser.isVerified,
        role: updatedUser.role,
        isBlocked: !!updatedUser.isBlocked,
        isApproved: !!updatedUser.isApproved,
      },
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500);
    throw new Error('Failed to update profile');
  }
});

const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.params;
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE verificationToken = ?', [token]);
    const user = rows[0];
    if (!user) {
      res.status(400);
      throw new Error('Invalid or expired token');
    }
    if (user.isVerified) {
      return res.status(400).json({ success: false, message: 'Email already verified' });
    }

    await pool.query('UPDATE users SET isVerified = ?, verificationToken = ?, updatedAt = NOW() WHERE id = ?', [
      true,
      null,
      user.id,
    ]);
    const accessToken = generateAccessToken(res, user.id, user.role);
    const refreshToken = await generateRefreshToken(pool, user.id);

    res.status(200).json({
      success: true,
      message: 'Email verified successfully',
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        isVerified: true,
        role: user.role,
      },
      token: accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error('Verify email error:', error);
    res.status(500);
    throw new Error('Verification failed');
  }
});

const refreshToken = asyncHandler(async (req, res) => {
  const refreshToken = req.body.refreshToken;
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  if (!refreshToken) {
    res.status(401);
    throw new Error('Refresh token required');
  }

  try {
    const storedToken = await verifyRefreshToken(pool, refreshToken);
    if (!storedToken) {
      res.status(401);
      throw new Error('Invalid or expired refresh token');
    }

    const [rows] = await pool.query('SELECT id, role, isBlocked, isApproved FROM users WHERE id = ?', [
      storedToken.user_id,
    ]);
    const user = rows[0];
    if (!user) {
      res.status(401);
      throw new Error('User not found');
    }
    if (user.isBlocked) {
      res.status(403);
      throw new Error('Account is blocked');
    }
    if (!user.isApproved) {
      res.status(403);
      throw new Error('Account not approved');
    }

    await deleteRefreshToken(pool, refreshToken);

    const newAccessToken = generateAccessToken(res, user.id, user.role);
    const newRefreshToken = await generateRefreshToken(pool, user.id);

    res.status(200).json({
      success: true,
      token: newAccessToken,
      refreshToken: newRefreshToken,
    });
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500);
    throw new Error('Failed to refresh token');
  }
});

const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.status(400);
    throw new Error('Email required');
  }

  try {
    const pool = req.app.locals.pool;
    if (!pool) {
      res.status(500);
      throw new Error('Database connection not available');
    }
    const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    const user = rows[0];
    if (!user) {
      res.status(404);
      throw new Error('Email not found');
    }
    const resetToken = crypto.randomBytes(32).toString('hex');
    await pool.query('UPDATE users SET verificationToken = ? WHERE id = ?', [resetToken, user.id]);
    const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
    await sendEmail({
      to: email,
      subject: 'Reset Your Password',
      html: `<p>Reset your password by clicking <a href="${resetUrl}">here</a>.</p>`,
    });
    res.status(200).json({ success: true, message: 'Password reset email sent successfully' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500);
    throw new Error('Reset failed');
  }
});

const googleAuthCallback = asyncHandler(async (req, res) => {
  const { token } = req.body;
  if (!token) {
    res.status(400);
    throw new Error('No token provided');
  }

  try {
    const pool = req.app.locals.pool;
    if (!pool) {
      res.status(500);
      throw new Error('Database connection not available');
    }
    const ticket = await googleClient.verifyIdToken({
      idToken: token,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload?.email) {
      res.status(400);
      throw new Error('No email found in Google payload');
    }
    const email = payload.email;
    const firstName = payload.given_name || 'Google';
    const lastName = payload.family_name || 'User';

    let [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    let user = rows[0];

    if (!user) {
      const id = uuidv4();
      await pool.query(
        'INSERT INTO users (id, firstName, lastName, email, isVerified, isApproved, isBlocked, role, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
        [id, firstName, lastName, email, true, true, false, 'user']
      );
      [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
      user = rows[0];
    }

    if (user.isBlocked) {
      res.status(403);
      throw new Error('Account is blocked');
    }
    if (!user.isApproved) {
      res.status(403);
      throw new Error('Account not approved');
    }

    const accessToken = generateAccessToken(res, user.id, user.role);
    const refreshToken = await generateRefreshToken(pool, user.id);

    await pool.query('UPDATE users SET lastLogin = NOW() WHERE id = ?', [user.id]);

    res.status(200).json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isVerified: !!user.isVerified,
        role: user.role,
        isBlocked: !!user.isBlocked,
        isApproved: !!user.isApproved,
      },
      token: accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error('Google auth error:', error);
    res.status(401);
    throw new Error('Google authentication failed');
  }
});

const getAdminMe = asyncHandler(async (req, res) => {
  const pool = req.app.locals.pool;
  if (!pool) {
    res.status(500);
    throw new Error('Database connection not available');
  }
  if (!req.user?.id) {
    res.status(401);
    throw new Error('User not authenticated');
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
    const user = rows[0];
    if (!user || user.role !== 'admin') {
      res.status(401);
      throw new Error('Not authorized as admin');
    }
    res.status(200).json({
      success: true,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        isVerified: !!user.isVerified,
        role: user.role,
        isBlocked: !!user.isBlocked,
        isApproved: !!user.isApproved,
      },
    });
  } catch (error) {
    console.error('Admin profile fetch error:', error);
    res.status(500);
    throw new Error('Failed to fetch admin profile');
  }
});

export {
  signup,
  signin,
  adminSignup,
  adminSignin,
  logoutUser,
  adminLogout,
  getUserProfile,
  updateProfile,
  verifyEmail,
  refreshToken,
  forgotPassword,
  googleAuthCallback,
  getAdminMe,
};
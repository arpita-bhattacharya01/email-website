import asyncHandler from 'express-async-handler';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { sendEmail } from './emailController.js';

// Generate a 6-digit numeric OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// @desc    Send OTP for email verification
// @route   POST /api/send-otp
export const sendOTP = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.status(400);
    throw new Error('Email is required');
  }

  const pool = req.app.locals.pool;
  const otp = generateOTP();
  const hashedOTP = crypto.createHash('sha256').update(otp).digest('hex');
  const id = uuidv4();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  try {
    // Delete existing OTPs for this email
    await pool.query('DELETE FROM otps WHERE email = ?', [email]);

    // Store hashed OTP in DB
    await pool.query('INSERT INTO otps (id, email, otp, expiresAt) VALUES (?, ?, ?, ?)', [
      id,
      email,
      hashedOTP,
      expiresAt,
    ]);

    // Send OTP email
    const message = `
      <h2>Your OTP Code</h2>
      <p>Use the following OTP to verify your email:</p>
      <h3>${otp}</h3>
      <p>This OTP will expire in 10 minutes.</p>
    `;
    await sendEmail({
      to: email,
      subject: 'Email Verification OTP',
      html: message,
    });

    res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500);
    throw new Error('Failed to send OTP');
  }
});

// @desc    Verify OTP
// @route   POST /api/verify-otp
export const verifyOTP = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) {
    res.status(400);
    throw new Error('Email and OTP are required');
  }

  const pool = req.app.locals.pool;
  const hashedOTP = crypto.createHash('sha256').update(otp).digest('hex');

  try {
    const [rows] = await pool.query(
      'SELECT * FROM otps WHERE email = ? AND otp = ? AND expiresAt > NOW()',
      [email, hashedOTP]
    );
    const record = rows[0];
    if (!record) {
      res.status(400);
      throw new Error('Invalid or expired OTP');
    }

    // Delete OTP after successful verification
    await pool.query('DELETE FROM otps WHERE id = ?', [record.id]);

    res.status(200).json({ success: true, message: 'OTP verified successfully' });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500);
    throw new Error('OTP verification failed');
  }
});
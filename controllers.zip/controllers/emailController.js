import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';
import asyncHandler from 'express-async-handler';

// Define __filename and __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// @desc    Send Email with Attachments
// @route   POST /api/auth/emails
export const sendEmail = asyncHandler(async (req, res) => {
  const { to, recipientEmail, subject, text, body, labels = [] } = req.body;
  const files = req.files;
  const recipientEmailAddress = to || recipientEmail;
  const emailBody = text || body;

  if (!recipientEmailAddress || !subject || !emailBody) {
    return res.status(400).json({
      success: false,
      message: 'To/recipientEmail, subject, and text/body are required',
    });
  }

  const pool = req.app.locals.pool;
  const transporter = req.app.locals.transporter;

  try {
    // Validate labels as array
    if (!Array.isArray(labels)) {
      return res.status(400).json({
        success: false,
        message: 'Labels must be an array',
      });
    }

    // Prepare attachments
    const attachments = files
      ? files.map((file) => ({
          filename: file.originalname,
          path: join(__dirname, '../Uploads', file.filename),
          contentType: file.mimetype,
        }))
      : [];

    // Send email via SMTP
    const mailOptions = {
      from: `"App Mail" <${process.env.SMTP_USER || 'no-reply@emailapp.com'}>`,
      to: recipientEmailAddress,
      subject,
      html: `<p>${emailBody}</p>`,
      attachments,
    };
    await transporter.sendMail(mailOptions);

    // Optionally store email if recipient is a registered user
    const [recipientRows] = await pool.query('SELECT id FROM users WHERE email = ?', [
      recipientEmailAddress,
    ]);
    const recipient = recipientRows[0];

    if (recipient && req.user?.id) {
      const emailData = {
        id: uuidv4(),
        sender_id: req.user.id,
        recipient_id: recipient.id,
        recipient_email: recipientEmailAddress,
        subject,
        body: emailBody,
        folder: 'sent',
        is_read: false,
        is_starred: false,
        labels: JSON.stringify(labels),
      };

      // Save to sender's 'sent' folder
      await pool.query(
        'INSERT INTO emails (id, sender_id, recipient_id, recipient_email, subject, body, folder, is_read, is_starred, labels, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
        [
          emailData.id,
          emailData.sender_id,
          emailData.recipient_id,
          emailData.recipient_email,
          emailData.subject,
          emailData.body,
          emailData.folder,
          emailData.is_read,
          emailData.is_starred,
          emailData.labels,
        ]
      );

      // Save to recipient's 'inbox' folder
      emailData.id = uuidv4();
      emailData.folder = 'inbox';
      await pool.query(
        'INSERT INTO emails (id, sender_id, recipient_id, recipient_email, subject, body, folder, is_read, is_starred, labels, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
        [
          emailData.id,
          emailData.sender_id,
          emailData.recipient_id,
          emailData.recipient_email,
          emailData.subject,
          emailData.body,
          emailData.folder,
          emailData.is_read,
          emailData.is_starred,
          emailData.labels,
        ]
      );
    }

    res.status(200).json({ success: true, message: 'Email sent successfully' });
  } catch (error) {
    console.error('Send email error:', error);
    if (error.code === 'EAUTH') {
      return res.status(500).json({ success: false, message: 'SMTP authentication failed' });
    }
    if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
      return res.status(503).json({ success: false, message: 'SMTP server unreachable' });
    }
    throw new Error(`Failed to send email: ${error.message}`);
  }
});

// @desc    Fetch Emails
// @route   GET /api/auth/emails
export const getEmails = asyncHandler(async (req, res) => {
  if (!req.user?.id) {
    return res.status(401).json({ success: false, message: 'Unauthorized: User not logged in' });
  }

  const pool = req.app.locals.pool;
  const { folder = 'inbox', page = '1', limit = '20', isRead, isStarred, search } = req.query;

  const filters = {
    userId: req.user.id,
    folder: String(folder),
    isRead: isRead !== undefined ? isRead === 'true' : undefined,
    isStarred: isStarred !== undefined ? isStarred === 'true' : undefined,
    search: search ? String(search) : undefined,
    limit: parseInt(String(limit), 10) || 20,
    offset: (parseInt(String(page), 10) - 1) * (parseInt(String(limit), 10) || 20),
  };

  let query = `
    SELECT id, sender_id, recipient_id, recipient_email, subject, body, folder, is_read, is_starred, labels, created_at
    FROM emails
    WHERE (sender_id = ? OR recipient_id = ?) AND folder = ?
  `;
  let queryParams = [filters.userId, filters.userId, filters.folder];

  if (filters.isRead !== undefined) {
    query += ' AND is_read = ?';
    queryParams.push(filters.isRead);
  }
  if (filters.isStarred !== undefined) {
    query += ' AND is_starred = ?';
    queryParams.push(filters.isStarred);
  }
  if (filters.search) {
    query += ' AND (subject LIKE ? OR body LIKE ? OR recipient_email LIKE ?)';
    queryParams.push(`%${filters.search}%`, `%${filters.search}%`, `%${filters.search}%`);
  }

  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  queryParams.push(filters.limit, filters.offset);

  const [emails] = await pool.query(query, queryParams);

  const [countResult] = await pool.query(
    `SELECT COUNT(*) as totalCount FROM emails WHERE (sender_id = ? OR recipient_id = ?) AND folder = ?`,
    [filters.userId, filters.userId, filters.folder]
  );
  const totalCount = countResult[0].totalCount;

  res.json({
    success: true,
    emails: emails.map((email) => ({
      ...email,
      labels: email.labels ? JSON.parse(email.labels) : [],
    })),
    totalCount,
    totalPages: Math.ceil(totalCount / filters.limit),
    currentPage: parseInt(String(page), 10),
  });
});

// @desc    Get Email by ID
// @route   GET /api/auth/emails/:id
export const getEmailById = asyncHandler(async (req, res) => {
  if (!req.user?.id) {
    return res.status(401).json({ success: false, message: 'Unauthorized: User not logged in' });
  }

  const pool = req.app.locals.pool;
  const [rows] = await pool.query(
    'SELECT * FROM emails WHERE id = ? AND (sender_id = ? OR recipient_id = ?)',
    [req.params.id, req.user.id, req.user.id]
  );
  const email = rows[0];

  if (!email) {
    return res.status(404).json({ success: false, message: 'Email not found' });
  }

  // Mark as read if recipient
  if (email.recipient_id === req.user.id && !email.is_read) {
    await pool.query('UPDATE emails SET is_read = TRUE WHERE id = ?', [email.id]);
    email.is_read = true;
  }

  res.json({
    success: true,
    email: {
      ...email,
      labels: email.labels ? JSON.parse(email.labels) : [],
    },
  });
});

// @desc    Update Email (mark read/star, change folder or labels)
// @route   PUT /api/auth/emails/:id
export const updateEmail = asyncHandler(async (req, res) => {
  if (!req.user?.id) {
    return res.status(401).json({ success: false, message: 'Unauthorized: User not logged in' });
  }

  const { isRead, isStarred, folder, labels } = req.body;
  const pool = req.app.locals.pool;

  const updateData = {};
  if (isRead !== undefined) updateData.is_read = isRead;
  if (isStarred !== undefined) updateData.is_starred = isStarred;
  if (folder) updateData.folder = folder;
  if (labels !== undefined) updateData.labels = Array.isArray(labels) ? JSON.stringify(labels) : JSON.stringify([]);

  if (Object.keys(updateData).length === 0) {
    return res.status(400).json({ success: false, message: 'No updates provided' });
  }

  let query = 'UPDATE emails SET ';
  const queryParams = [];
  Object.keys(updateData).forEach((key, index) => {
    query += `${key} = ?${index < Object.keys(updateData).length - 1 ? ', ' : ''}`;
    queryParams.push(updateData[key]);
  });
  query += ' WHERE id = ? AND (sender_id = ? OR recipient_id = ?)';
  queryParams.push(req.params.id, req.user.id, req.user.id);

  const [result] = await pool.query(query, queryParams);
  if (result.affectedRows === 0) {
    return res.status(404).json({ success: false, message: 'Email not found' });
  }

  const [updatedRows] = await pool.query(
    'SELECT * FROM emails WHERE id = ? AND (sender_id = ? OR recipient_id = ?)',
    [req.params.id, req.user.id, req.user.id]
  );
  const updatedEmail = updatedRows[0];

  res.json({
    success: true,
    email: {
      ...updatedEmail,
      labels: updatedEmail.labels ? JSON.parse(updatedEmail.labels) : [],
    },
  });
});

// @desc    Move Email to Trash
// @route   POST /api/auth/emails/:id/trash
export const trashEmail = asyncHandler(async (req, res) => {
  if (!req.user?.id) {
    return res.status(401).json({ success: false, message: 'Unauthorized: User not logged in' });
  }

  const pool = req.app.locals.pool;
  const [result] = await pool.query(
    'UPDATE emails SET folder = "trash" WHERE id = ? AND (sender_id = ? OR recipient_id = ?)',
    [req.params.id, req.user.id, req.user.id]
  );

  if (result.affectedRows === 0) {
    return res.status(404).json({ success: false, message: 'Email not found' });
  }

  res.json({ success: true, message: 'Email moved to trash' });
});

// @desc    Permanently Delete Email
// @route   DELETE /api/auth/emails/:id
export const deleteEmail = asyncHandler(async (req, res) => {
  if (!req.user?.id) {
    return res.status(401).json({ success: false, message: 'Unauthorized: User not logged in' });
  }

  const pool = req.app.locals.pool;
  const [result] = await pool.query(
    'DELETE FROM emails WHERE id = ? AND (sender_id = ? OR recipient_id = ?)',
    [req.params.id, req.user.id, req.user.id]
  );

  if (result.affectedRows === 0) {
    return res.status(404).json({ success: false, message: 'Email not found' });
  }

  res.json({ success: true, message: 'Email deleted successfully' });
});
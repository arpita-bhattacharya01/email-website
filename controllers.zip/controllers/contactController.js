import asyncHandler from 'express-async-handler';
import { v4 as uuidv4 } from 'uuid';
import { sendEmail } from './emailController.js';

// @desc    Submit Contact Form
// @route   POST /api/contact
export const submitContactForm = asyncHandler(async (req, res) => {
  const { name, email, message } = req.body;

  // Validate inputs
  if (!name || !email || !message) {
    res.status(400);
    throw new Error('All fields (name, email, message) are required');
  }

  // Validate email format
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/i;
  if (!emailRegex.test(email)) {
    res.status(400);
    throw new Error('Invalid email format');
  }

  // Validate ADMIN_EMAIL
  if (!process.env.ADMIN_EMAIL) {
    console.error('Environment variable ADMIN_EMAIL is missing');
    res.status(500);
    throw new Error('Server configuration error');
  }

  const pool = req.app.locals.pool;
  const id = uuidv4();

  try {
    // Store in contacts table
    await pool.query('INSERT INTO contacts (id, name, email, message, createdAt) VALUES (?, ?, ?, ?, NOW())', [
      id,
      name,
      email,
      message,
    ]);

    // Prepare and send email notification
    const htmlContent = `
      <h1>New Contact Request</h1>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Message:</strong><br/>${message}</p>
    `;

    await sendEmail({
      to: process.env.ADMIN_EMAIL,
      subject: 'New Contact Form Submission',
      html: htmlContent,
    });

    res.status(200).json({ success: true, message: 'Contact form submitted and email sent successfully' });
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500);
    throw new Error('Failed to process contact form submission');
  }
});

export default {
  submitContactForm,
};
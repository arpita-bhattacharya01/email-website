CREATE DATABASE email;
USE email;

CREATE DATABASE email;

SELECT * FROM email.users;


CREATE TABLE IF NOT EXISTS emails (
  id VARCHAR(36) PRIMARY KEY,
  senderId VARCHAR(36) NOT NULL,
  recipientId VARCHAR(36) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  folder VARCHAR(50) NOT NULL,
  labels JSON,
  attachments JSON,
  isRead BOOLEAN DEFAULT FALSE,
  isStarred BOOLEAN DEFAULT FALSE,
  isTrash BOOLEAN DEFAULT FALSE,
  isDeleted BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (senderId) REFERENCES users(id),
  FOREIGN KEY (recipientId) REFERENCES users(id)
);


CREATE TABLE support_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  createdAt DATETIME NOT NULL
);


ALTER TABLE users ADD COLUMN role ENUM('user', 'admin') NOT NULL DEFAULT 'user';


CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY,
  firstName VARCHAR(50) NOT NULL,
  lastName VARCHAR(50) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  isVerified BOOLEAN DEFAULT FALSE,
  verificationToken VARCHAR(64),
  role ENUM('user', 'admin') DEFAULT 'user',
  isBlocked BOOLEAN DEFAULT FALSE,
  isApproved BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  lastLogin TIMESTAMP
);


CREATE TABLE otps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  otp VARCHAR(6) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users
ADD COLUMN isVerified BOOLEAN DEFAULT FALSE,
ADD COLUMN verificationToken VARCHAR(255) NULL;


CREATE TABLE email_recipients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  emailId CHAR(36),
  userId INT,                           -- recipient user ID
  type ENUM('to', 'cc', 'bcc') DEFAULT 'to',  -- recipient type
  FOREIGN KEY (emailId) REFERENCES emails(id),
  FOREIGN KEY (userId) REFERENCES users(id)
);

CREATE TABLE sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId INT,
  token TEXT,
  expiresAt DATETIME,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);

CCREATE TABLE IF NOT EXISTS refresh_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  token VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

SELECT id, email, role FROM users WHERE email = 'john.doe1234@example.com';



INSERT INTO email.users (firstName, lastName, email, password) VALUES ('Test', 'User', 'test1234@example.com', 'hashed');

SELECT user, host, authentication_string FROM mysql.users WHERE user = 'root';

-----------------------------------------
INSERT INTO users (id, firstName, lastName, email) VALUES
('uuid-1', 'John', 'Doe', 'john@example.com'),
('uuid-2', 'Jane', 'Smith', 'jane@example.com');

INSERT INTO emails (id, senderId, recipientId, subject, body, isRead, isStarred, isTrash, isDeleted, folder, created_at) VALUES
('uuid-email-1', 'uuid-1', 'uuid-2', 'Welcome Email', 'Hello, welcome to our platform!', FALSE, FALSE, FALSE, FALSE, 'inbox', '2025-05-29 12:00:00'),
('uuid-email-2', 'uuid-2', 'uuid-1', 'Meeting Invite', 'Please join our meeting tomorrow.', TRUE, TRUE, FALSE, FALSE, 'sent', '2025-05-28 10:00:00'),
('uuid-email-3', 'uuid-1', 'uuid-2', 'Draft Email', 'This is a draft.', FALSE, FALSE, FALSE, FALSE, 'drafts', '2025-05-27 09:00:00'),
('uuid-email-4', 'uuid-2', 'uuid-1', 'Trashed Email', 'This is in trash.', FALSE, FALSE, TRUE, FALSE, 'trash', '2025-05-26 08:00:00');

-----------------------------------------------------------------

INSERT INTO users 
(id, firstName, lastName, email, password_hash, isVerified, verificationToken, role, isBlocked, isApproved, createdAt, updatedAt)
VALUES
(UUID(), 'Admin', 'User', 'admin1234@gmail.com', '$2a$10$KsNJ0P9wqONNn7t5q6DdxeUMWqgJUeGnbf1S2JeqogC7/NiOFoHTK', 1, NULL, 'admin', 0, 1, NOW(), NOW());

------------------------------------------------------------------

INSERT INTO users (
  id, firstName, lastName, email, password_hash, isBlocked, isApproved, createdAt, updatedAt
) VALUES (
  UUID(), 'Admin', 'User', 'admin1234@gmail.com', '$2y$10$aBcdEfGhIjKlMnOpQrStuvWxYz0123456789ABCD.EFGHIJKLmnopq',  -- bcrypt hash of 'admin1234'
  FALSE, TRUE, NOW(), NOW()
);

INSERT INTO users 
        (id, firstName, lastName, email, password_hash, isBlocked, isApproved, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())

SELECT * FROM emails WHERE folder IN ('sent', 'inbox');

-----------------------------
SELECT * FROM users WHERE email = 'test1234@example.com';
SELECT * FROM refresh_tokens WHERE user_id = '123e4567-e89b-12d3-a456-426614174000';

------------------------------------------------

INSERT INTO users (id, firstName, lastName, email, password_hash, role)
VALUES ('123e4567-e89b-12d3-a456-426614174000', 'Test', 'User', 'test1234@example.com', '$2a$10$your_hashed_password', 'user');

---------------------------------------------

SELECT * FROM users WHERE email = 'test1234@example.com';
SELECT * FROM refresh_tokens WHERE user_id = '123e4567-e89b-12d3-a456-426614174000';

--------------------------------------------------
INSERT INTO users (id, firstName, lastName, email, password_hash, role, isVerified, profilePicture)
VALUES ('admin-123', 'Admin', 'User', 'admin1234@example.com', '$2a$10$your_admin_hashed_password', 'admin', TRUE, 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y');

----------------------------------------------

SELECT * FROM email.users;
SELECT * FROM email.contacts;
SELECT * FROM email.otps;

----------------------------------------------------

-- Create database
CREATE DATABASE IF NOT EXISTS email;
USE email;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY,
  firstName VARCHAR(100),
  lastName VARCHAR(100),
  email VARCHAR(255) UNIQUE,
  password_hash VARCHAR(255),
  profilePicture TEXT DEFAULT NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  isVerified BOOLEAN DEFAULT FALSE,
  verificationToken VARCHAR(255) DEFAULT NULL,
  isBlocked BOOLEAN DEFAULT FALSE,
  isApproved BOOLEAN DEFAULT FALSE,
  lastLogin DATETIME DEFAULT NULL,
  approvedAt DATETIME DEFAULT NULL,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- OTPs table
CREATE TABLE IF NOT EXISTS otps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  otp VARCHAR(6) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Emails table
CREATE TABLE IF NOT EXISTS emails (
  id CHAR(36) PRIMARY KEY,
  senderId VARCHAR(36) NOT NULL,
  recipientId VARCHAR(36) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  isRead BOOLEAN DEFAULT FALSE,
  isStarred BOOLEAN DEFAULT FALSE,
  isTrash BOOLEAN DEFAULT FALSE,
  isDeleted BOOLEAN DEFAULT FALSE,
  folder ENUM('inbox', 'sent', 'drafts', 'trash') DEFAULT 'inbox',
  labels TEXT,
  attachments TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (senderId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (recipientId) REFERENCES users(id) ON DELETE CASCADE
);

-- Email Recipients table (CC/BCC support)
CREATE TABLE IF NOT EXISTS email_recipients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  emailId CHAR(36),
  userId VARCHAR(36),
  type ENUM('to', 'cc', 'bcc') DEFAULT 'to',
  FOREIGN KEY (emailId) REFERENCES emails(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- Support messages
CREATE TABLE IF NOT EXISTS support_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Sessions (optional table)
CREATE TABLE IF NOT EXISTS sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  userId VARCHAR(36),
  token TEXT NOT NULL,
  expiresAt DATETIME,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

-- Refresh tokens
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  token VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,
  INDEX (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample Users
INSERT INTO users (
  id, firstName, lastName, email, password_hash, isBlocked, isApproved, createdAt, updatedAt
) VALUES
  ('uuid-1', 'John', 'Doe', 'john@example.com', '$2y$10$abcdefgh...', FALSE, TRUE, NOW(), NOW()),
  ('uuid-2', 'Jane', 'Smith', 'jane@example.com', '$2y$10$ijklmnop...', FALSE, TRUE, NOW(), NOW());

-- Sample Emails
INSERT INTO emails (
  id, senderId, recipientId, subject, body, isRead, isStarred, isTrash, isDeleted, folder, created_at
) VALUES
  ('uuid-email-1', 'uuid-1', 'uuid-2', 'Welcome Email', 'Hello, welcome!', FALSE, FALSE, FALSE, FALSE, 'inbox', NOW()),
  ('uuid-email-2', 'uuid-2', 'uuid-1', 'Meeting Invite', 'Let\'s meet.', TRUE, TRUE, FALSE, FALSE, 'sent', NOW());

-- Sample Refresh Token
INSERT INTO refresh_tokens (
  user_id, token, expires_at
) VALUES (
  'uuid-1', 'sample_refresh_token_123456789', DATE_ADD(NOW(), INTERVAL 30 DAY)
);
